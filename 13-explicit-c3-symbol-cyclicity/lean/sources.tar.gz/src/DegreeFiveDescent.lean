module
public import FixedCenter
public import Mathlib.LinearAlgebra.FiniteDimensional.Basic

@[expose] public section
noncomputable section
open Module Submodule
namespace C3BasisDescent
variable {K A : Type*} [Field K] [DivisionRing A] [Algebra K A]

/-- The 25-dimensional conclusion uses an actual basis, not a dimension axiom. -/
theorem finrank_fixedAlgebra_twentyFive
    (b : Basis (Fin 5 × Fin 5) K A)
    (σ : A ≃+* A) (τ : K ≃+* K)
    (hsemi : ∀ (c : K) (a : A), σ (c • a) = τ c • σ a)
    (horder : ∀ a : A, σ (σ (σ a)) = a)
    (x y z : K) (hx : τ x = y) (hy : τ y = z) (hz : τ z = x) (hxy : x ≠ y) :
    Module.finrank (fixedField τ) (fixedAlgebra σ τ hsemi) = 25 := by
  letI := b.finiteDimensional_of_finite
  rw [finrank_fixedAlgebra_of_cycle σ τ hsemi horder x y z hx hy hz hxy,
    Module.finrank_eq_card_basis b]
  decide

/-- The inverse structure is derived from the inherited domain and finite basis descent. -/
@[implicit_reducible]
def fixedDivisionRing
    (b : Basis (Fin 5 × Fin 5) K A)
    (σ : A ≃+* A) (τ : K ≃+* K)
    (hsemi : ∀ (c : K) (a : A), σ (c • a) = τ c • σ a)
    (horder : ∀ a : A, σ (σ (σ a)) = a)
    (x y z : K) (hx : τ x = y) (hy : τ y = z) (hz : τ z = x) (hxy : x ≠ y) :
    DivisionRing (fixedAlgebra σ τ hsemi) := by
  have hdim := finrank_fixedAlgebra_twentyFive b σ τ hsemi horder x y z hx hy hz hxy
  letI : FiniteDimensional (fixedField τ) (fixedAlgebra σ τ hsemi) :=
    FiniteDimensional.of_finrank_pos (by rw [hdim]; decide)
  exact divisionRingOfFiniteDimensional (fixedField τ) (fixedAlgebra σ τ hsemi)

/-- Center and dimension of the concrete fixed algebra under a scalar three-cycle. -/
theorem degreeFive_descent
    (b : Basis (Fin 5 × Fin 5) K A)
    (σ : A ≃+* A) (τ : K ≃+* K)
    (hsemi : ∀ (c : K) (a : A), σ (c • a) = τ c • σ a)
    (horder : ∀ a : A, σ (σ (σ a)) = a)
    (x y z : K) (hx : τ x = y) (hy : τ y = z) (hz : τ z = x) (hxy : x ≠ y)
    (hcenter : ∀ a : A, (∀ z : A, a * z = z * a) ↔
      ∃ c : K, algebraMap K A c = a) :
    Module.finrank (fixedField τ) (fixedAlgebra σ τ hsemi) = 25 ∧
      ∀ d : fixedAlgebra σ τ hsemi,
        (∀ z : fixedAlgebra σ τ hsemi, d * z = z * d) ↔
          ∃ c : fixedField τ,
            algebraMap (fixedField τ) (fixedAlgebra σ τ hsemi) c = d := by
  refine ⟨finrank_fixedAlgebra_twentyFive b σ τ hsemi horder x y z hx hy hz hxy, ?_⟩
  intro d
  exact center_fixedAlgebra σ τ hsemi
    (C3Interpolation.span_fixed_eq_top_of_cycle σ τ hsemi horder x y z hx hy hz hxy)
    hcenter d

end C3BasisDescent
