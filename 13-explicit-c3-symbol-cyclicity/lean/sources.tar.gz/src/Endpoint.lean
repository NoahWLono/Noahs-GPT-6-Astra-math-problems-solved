module
public import Cyclic
public import Maximal
public import FifthRoots

@[expose] public section
namespace PrimeCyclicityEndpoint

/-- Abstract supporting theorem only. It does not construct the generic quantum division
algebra, its fixed algebra, the candidate element, or any of their required hypotheses. -/
theorem abstract_cyclicity_endpoint
    (F D : Type*) [Field F] [DivisionRing D] [Algebra F D] [FiniteDimensional F D]
    (hd : Module.finrank F D = 25) (hc : CenterIsScalars F D)
    (r : D) (hn : r ∉ Set.range (algebraMap F D))
    (a : F) (hp : r ^ 5 = algebraMap F D a)
    (ζ : F) (hζ : IsPrimitiveRoot ζ 5) :
    Module.finrank F (Generated F D r) = 5 ∧
    IsGalois F (Generated F D r) ∧
    IsCyclic (Gal(Generated F D r/F)) ∧
    ∀ M : Subalgebra F D, Generated F D r ≤ M →
      (∀ x ∈ M, ∀ y ∈ M, x * y = y * x) → M = Generated F D r := by
  obtain ⟨hg, hcyc⟩ := generated_galois_cyclic F D hd r hn a hp ζ hζ
  exact ⟨generated_finrank_eq_five F D hd r hn a hp, hg, hcyc,
    fun M hM hcomm => generated_maximal_commutative F D hd hc r hn a hp M hM hcomm⟩

#print abstract_cyclicity_endpoint
#print fifth_root_is_scalar_power
#print axioms abstract_cyclicity_endpoint
#print axioms fifth_root_is_scalar_power
end PrimeCyclicityEndpoint
