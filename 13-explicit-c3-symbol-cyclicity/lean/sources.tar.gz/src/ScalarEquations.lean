module
public import QuantumPower
public import Mathlib.Tactic.LinearCombination

@[expose] public section
namespace TwoCoefficientObstruction
variable {F : Type*} [Field F] [CharZero F]

/-- Pure scalar consequences; no coordinate or basis assertion is hidden here. -/
theorem scalar_equations_force_equal (x y : F)
    (h₁ : x ^ 2 * y + x * y ^ 2 = 2)
    (h₂ : 2 * x ^ 2 * y - x * y ^ 2 = 1) :
    x = y ∧ x ≠ 0 ∧ y ≠ 0 := by
  have hA : x ^ 2 * y = 1 := by
    linear_combination (1 / 3 : F) * h₁ + (1 / 3 : F) * h₂
  have hB : x * y ^ 2 = 1 := by
    linear_combination (2 / 3 : F) * h₁ - (1 / 3 : F) * h₂
  have hx : x ≠ 0 := by intro hx; simp [hx] at hA
  have hy : y ≠ 0 := by intro hy; simp [hy] at hA
  refine ⟨?_, hx, hy⟩
  apply mul_right_cancel₀ (mul_ne_zero hx hy)
  calc
    x * (x * y) = x ^ 2 * y := by ring
    _ = x * y ^ 2 := hA.trans hB.symm
    _ = y * (x * y) := by ring

#print axioms scalar_equations_force_equal
end TwoCoefficientObstruction
