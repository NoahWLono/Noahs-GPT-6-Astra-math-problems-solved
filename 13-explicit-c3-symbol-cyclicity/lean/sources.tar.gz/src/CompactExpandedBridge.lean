module
public import SemanticBridge

@[expose] public section
namespace CompactLaurentBridge
open PrimeCyclicity CompactC3Invariance
variable {K D : Type*} [Field K] [DivisionRing D] [Algebra K D]

/-- Concrete bridge from the frozen expanded 69-term evaluator to the compact expression.
All arithmetic is certified; the equality itself is not a hypothesis. -/
theorem numerator_eq_compact
    (q : K) (hq : IsPrimitiveRoot q 5) (Q U V : Dˣ)
    (hQ : (Q : D) = algebraMap K D q) (hUV : U * V = Q * V * U) :
    evalLaurent q U V numerator =
      compactNumerator (algebraMap K D q) (U : D) (V : D) ((U : D) * (V : D))⁻¹ := by
  have h₄ : q ^ 4 = -(1 + q + q ^ 2 + q ^ 3) := by
    have hp : (q - 1) * (q ^ 4 + (1 + q + q ^ 2 + q ^ 3)) = 0 := by
      calc
        _ = q ^ 5 - 1 := by ring
        _ = 0 := by rw [hq.pow_eq_one, sub_self]
    have hs := (mul_eq_zero.mp hp).resolve_left (sub_ne_zero.mpr (hq.ne_one (by decide)))
    exact (eq_neg_iff_add_eq_zero).mpr hs
  have hQ₅ : Q ^ 5 = 1 := by
    apply Units.ext
    simpa only [Units.val_pow_eq_pow_val, Units.val_one, hQ, ← map_pow, hq.pow_eq_one, map_one]
  have hQU : Commute Q U := by
    change Q * U = U * Q
    apply Units.ext
    simpa only [Units.val_mul, hQ] using Algebra.commutes q (U : D)
  have hQV : Commute Q V := by
    change Q * V = V * Q
    apply Units.ext
    simpa only [Units.val_mul, hQ] using Algebra.commutes q (V : D)
  exact numerator_eq_compact_explicit q Q U V hQ hQ₅ h₄ hq.pow_eq_one hUV hQU hQV

/-- Equivalent interface stated directly with the central scalar quantum relation. -/
theorem numerator_eq_compact_of_scalar_relation
    (q : K) (hq : IsPrimitiveRoot q 5) (U V : Dˣ)
    (hUV : (U : D) * V = algebraMap K D q * ((V : D) * U)) :
    evalLaurent q U V numerator =
      compactNumerator (algebraMap K D q) (U : D) (V : D) ((U : D) * (V : D))⁻¹ := by
  have hq0 : q ≠ 0 := by
    intro h
    have hp := hq.pow_eq_one
    simp [h] at hp
  have hqD0 : algebraMap K D q ≠ 0 := by
    intro h
    apply hq0
    exact (algebraMap K D).injective (by simpa using h)
  let Q : Dˣ := Units.mk0 (algebraMap K D q) hqD0
  have hrel : U * V = Q * V * U := by
    apply Units.ext
    change (U : D) * V = algebraMap K D q * (V : D) * U
    simpa only [mul_assoc] using hUV
  exact numerator_eq_compact q hq Q U V rfl hrel

/-- The expanded numerator is fixed by an actual automorphism with the supplied images. -/
theorem expanded_numerator_fixed
    (q : K) (hq : IsPrimitiveRoot q 5) (Q U V : Dˣ)
    (hQ : (Q : D) = algebraMap K D q) (hUV : U * V = Q * V * U)
    (σ : D ≃+* D) (hqσ : σ (algebraMap K D q) = algebraMap K D q)
    (hUσ : σ (U : D) = (V : D))
    (hVσ : σ (V : D) = ((U : D) * (V : D))⁻¹) :
    σ (evalLaurent q U V numerator) = evalLaurent q U V numerator := by
  rw [numerator_eq_compact q hq Q U V hQ hUV]
  exact compactNumerator_fixed_of_two_images σ (algebraMap K D q) (U : D) (V : D)
    U.ne_zero V.ne_zero hqσ hUσ hVσ

#print axioms numerator_eq_compact
#print axioms expanded_numerator_fixed
#check @numerator_eq_compact
end CompactLaurentBridge
