module
public import Operations
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
namespace CompactLaurentBridge
open PrimeCyclicity
def u : List Term := [
  (((Int.ofNat 1), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
def v : List Term := [
  (((Int.ofNat 0), (Int.ofNat 1)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
def ui : List Term := [
  (((Int.negSucc 0), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
def vi : List Term := [
  (((Int.ofNat 0), (Int.negSucc 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
def x : List Term := [
  (((Int.ofNat 5), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
def y : List Term := [
  (((Int.ofNat 0), (Int.ofNat 5)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
def c : List Term := [
  (((Int.ofNat 0), (Int.ofNat 0)), ((Int.ofNat 0), (Int.negSucc 4), (Int.negSucc 4), (Int.negSucc 4)))
]
end CompactLaurentBridge
