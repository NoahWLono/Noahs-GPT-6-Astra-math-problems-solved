module
public import modern.Numerator
public import CompactNumerator
public import Mathlib.RingTheory.RootsOfUnity.PrimitiveRoots

@[expose] public section
namespace CompactLaurentBridge
open PrimeCyclicity
variable {K D : Type*} [CommRing K] [DivisionRing D] [Algebra K D]
def negCoeff (a : Coeff) : Coeff := (-a.1, -a.2.1, -a.2.2.1, -a.2.2.2)
def negL (p : List Term) : List Term := p.map (fun t => (t.1, negCoeff t.2))
def addL (p r : List Term) : List Term := trimLaurent (mergeLaurent p r)
def subL (p r : List Term) : List Term := addL p (negL r)

theorem eval_neg (q : K) (U V : Dˣ) (p : List Term) :
    evalLaurent q U V (negL p) = -evalLaurent q U V p := by
  have hn (t : Term) : evalTerm q U V (t.1, negCoeff t.2) = -evalTerm q U V t := by
    have hc : evalCoeff q (negCoeff t.2) = -evalCoeff q t.2 := by
      simp [evalCoeff, negCoeff]
      ring
    simp only [evalTerm, hc, map_neg, neg_mul]
  induction p with
  | nil => simp [negL, evalLaurent]
  | cons t p ih =>
    change evalTerm q U V (t.1, negCoeff t.2) + evalLaurent q U V (negL p) =
      -(evalTerm q U V t + evalLaurent q U V p)
    rw [hn, ih, neg_add]

theorem eval_add (q : K) (U V : Dˣ) (p r : List Term) :
    evalLaurent q U V (addL p r) = evalLaurent q U V p + evalLaurent q U V r := by
  rw [addL, evalLaurent_trim, evalLaurent_merge]

theorem eval_sub (q : K) (U V : Dˣ) (p r : List Term) :
    evalLaurent q U V (subL p r) = evalLaurent q U V p - evalLaurent q U V r := by
  rw [subL, eval_add, eval_neg, sub_eq_add_neg]
end CompactLaurentBridge
