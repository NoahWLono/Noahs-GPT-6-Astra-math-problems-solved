module
public import Mathlib.Algebra.Ring.Equiv
public import Mathlib.Tactic.NoncommRing

/- Compact-expression invariance only;
no assertion that this expression equals the expanded 69-term candidate. -/
@[expose] public section
namespace CompactC3Invariance
variable {R : Type*} [Ring R]
abbrev Pair (R : Type*) := R × R

def pairMul (A B : Pair R) : Pair R :=
  (A.1 * B.1 - A.2 * B.2, A.1 * B.2 + A.2 * B.1 - A.2 * B.2)
def pairSub (A B : Pair R) : Pair R := (A.1 - B.1, A.2 - B.2)
def leftScale (c : R) (A : Pair R) : Pair R := (c * A.1, c * A.2)
def T (A : Pair R) : Pair R := (A.2 - A.1, -A.1)
def S (A : Pair R) : Pair R := (-A.2, A.1 - A.2)
def quartic (A : Pair R) : Pair R := pairMul (pairMul A A) (pairMul A A)
def covariant (c : R) (A B : Pair R) : Pair R :=
  pairMul (pairSub (quartic A) (leftScale c A)) B
def pairing (d P : Pair R) : R :=
  (2 * d.1 - d.2) * P.1 + (2 * d.2 - d.1) * P.2
def pairMap (σ : R ≃+* R) (A : Pair R) : Pair R := (σ A.1, σ A.2)

theorem pairMul_assoc (A B C : Pair R) :
    pairMul (pairMul A B) C = pairMul A (pairMul B C) := by
  apply Prod.ext <;> dsimp [pairMul] <;> noncomm_ring

theorem T_mul_T (A B : Pair R) : pairMul (T A) (T B) = S (pairMul A B) := by
  apply Prod.ext <;> dsimp [pairMul, T, S] <;> noncomm_ring

theorem S_mul_S (A B : Pair R) : pairMul (S A) (S B) = T (pairMul A B) := by
  apply Prod.ext <;> dsimp [pairMul, T, S] <;> noncomm_ring

theorem quartic_T (A : Pair R) : quartic (T A) = T (quartic A) := by
  simp only [quartic, T_mul_T, S_mul_S]

theorem T_sub (A B : Pair R) : T (pairSub A B) = pairSub (T A) (T B) := by
  apply Prod.ext <;> dsimp [T, pairSub] <;> noncomm_ring

theorem T_leftScale (c : R) (A : Pair R) : T (leftScale c A) = leftScale c (T A) := by
  apply Prod.ext <;> dsimp [T, leftScale] <;> noncomm_ring

/-- The quartic-linear expression times the second pair has covariance S. -/
theorem covariant_transform (c : R) (A B : Pair R) :
    covariant c (T A) (T B) = S (covariant c A B) := by
  unfold covariant
  rw [quartic_T, ← T_leftScale, ← T_sub, T_mul_T]

/-- Invariance preserves the indicated left-to-right order; commutativity is unnecessary. -/
theorem pairing_invariant (d P : Pair R) : pairing (S d) (S P) = pairing d P := by
  dsimp [pairing, S]
  simp only [two_mul]
  noncomm_ring

theorem pairMap_mul (σ : R ≃+* R) (A B : Pair R) :
    pairMap σ (pairMul A B) = pairMul (pairMap σ A) (pairMap σ B) := by
  apply Prod.ext <;> simp [pairMap, pairMul]

theorem pairMap_sub (σ : R ≃+* R) (A B : Pair R) :
    pairMap σ (pairSub A B) = pairSub (pairMap σ A) (pairMap σ B) := by
  apply Prod.ext <;> simp [pairMap, pairSub]

theorem pairMap_leftScale (σ : R ≃+* R) (c : R) (A : Pair R) :
    pairMap σ (leftScale c A) = leftScale (σ c) (pairMap σ A) := by
  apply Prod.ext <;> simp [pairMap, leftScale]

theorem pairMap_quartic (σ : R ≃+* R) (A : Pair R) :
    pairMap σ (quartic A) = quartic (pairMap σ A) := by
  simp only [quartic, pairMap_mul]

theorem pairMap_covariant (σ : R ≃+* R) (c : R) (A B : Pair R) :
    pairMap σ (covariant c A B) = covariant (σ c) (pairMap σ A) (pairMap σ B) := by
  simp only [covariant, pairMap_mul, pairMap_sub, pairMap_quartic, pairMap_leftScale]

theorem map_pairing (σ : R ≃+* R) (d P : Pair R) :
    σ (pairing d P) = pairing (pairMap σ d) (pairMap σ P) := by
  simp [pairing, pairMap, show (2 : R) = 1 + 1 from (one_add_one_eq_two).symm]

/-- Abstract fixedness theorem with covariance hypotheses exposed. -/
theorem compact_fixed_of_covariance (σ : R ≃+* R) (c : R) (A B d : Pair R)
    (hc : σ c = c) (hA : pairMap σ A = T A) (hB : pairMap σ B = T B)
    (hd : pairMap σ d = S d) :
    σ (pairing d (covariant c A B)) = pairing d (covariant c A B) := by
  rw [map_pairing, pairMap_covariant, hc, hA, hB, hd, covariant_transform,
    pairing_invariant]

#print axioms covariant_transform
#print axioms pairing_invariant
#print axioms compact_fixed_of_covariance
end CompactC3Invariance
