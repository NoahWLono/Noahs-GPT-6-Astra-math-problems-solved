module
public import GeneratedField
public import Mathlib.FieldTheory.KummerExtension

@[expose] public section
namespace PrimeCyclicityEndpoint
variable (F D : Type*) [Field F] [DivisionRing D] [Algebra F D]
  [FiniteDimensional F D]

/-- The canonical generator generates the field internally, where IntermediateField is valid. -/
theorem generator_adjoin_top (r : D) :
    IntermediateField.adjoin F ({generator F D r} : Set (Generated F D r)) = ⊤ := by
  apply IntermediateField.toSubalgebra_injective
  rw [IntermediateField.adjoin_simple_toSubalgebra_of_isAlgebraic
    (IsAlgebraic.of_finite F (generator F D r))]
  apply top_unique
  intro y _
  obtain ⟨q, hq⟩ := Algebra.adjoin_mem_exists_aeval F r y.property
  have hm := Polynomial.aeval_mem_adjoin_singleton (p := q) F (generator F D r)
  have heq : Polynomial.aeval (generator F D r) q = y := by
    apply Subtype.val_injective
    simpa [generator] using hq
  rwa [heq] at hm

/-- The known Kummer-theoretic cyclicity endpoint, with every algebraic hypothesis explicit. -/
theorem generated_galois_cyclic (hd : Module.finrank F D = 25)
    (r : D) (hn : r ∉ Set.range (algebraMap F D)) (a : F)
    (hp : r ^ 5 = algebraMap F D a) (ζ : F) (hζ : IsPrimitiveRoot ζ 5) :
    IsGalois F (Generated F D r) ∧ IsCyclic (Gal(Generated F D r/F)) := by
  have hdim := generated_finrank_eq_five F D hd r hn a hp
  have hroots : (primitiveRoots (Module.finrank F (Generated F D r)) F).Nonempty := by
    rw [hdim]
    exact ⟨ζ, (mem_primitiveRoots (by decide : 0 < 5)).mpr hζ⟩
  apply ((isCyclic_tfae F (Generated F D r) hroots).out 0 2).mpr
  refine ⟨generator F D r, ?_, generator_adjoin_top F D r⟩
  refine ⟨a, ?_⟩
  rw [hdim]
  apply Subtype.val_injective
  simpa [generator] using hp.symm

#print axioms generator_adjoin_top
#print axioms generated_galois_cyclic
end PrimeCyclicityEndpoint
