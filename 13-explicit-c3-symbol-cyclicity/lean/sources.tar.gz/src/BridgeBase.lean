module
public import modern.Numerator
public import Obstruction
public import Mathlib.LinearAlgebra.Basis.Defs
public import Mathlib.Algebra.GroupWithZero.Units.Lemmas
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

/- Concrete coordinate normalization. No coordinate formulas are hypotheses. -/
@[expose] public section
namespace ConcreteCoordinateBridge
open PrimeCyclicity Module
variable {K A : Type*} [Field K] [DivisionRing A] [Algebra K A]

def residue5 (n : ℤ) : Fin 5 :=
  ⟨(n % 5).toNat, by
    have h₀ := Int.emod_nonneg n (by decide : (5 : ℤ) ≠ 0)
    have h₁ := Int.emod_lt_of_pos n (by decide : (0 : ℤ) < 5)
    omega⟩

/-- Extract a central fifth power; there is no quantum commutation phase. -/
theorem normalize_zpow (U : Aˣ) (x : K)
    (hU : (U : A) ^ 5 = algebraMap K A x) (n : ℤ) :
    ((U ^ n : Aˣ) : A) =
      algebraMap K A (x ^ (n / 5)) * (U : A) ^ (residue5 n).val := by
  have he : n = 5 * (n / 5) + ((residue5 n).val : ℤ) := by
    simp only [residue5]
    have h := Int.mul_ediv_add_emod n 5
    have h₀ := Int.emod_nonneg n (by decide : (5 : ℤ) ≠ 0)
    omega
  have hp : U ^ n = (U ^ (5 : ℕ)) ^ (n / 5) * U ^ (residue5 n).val := by
    calc
      U ^ n = U ^ (5 * (n / 5) + ((residue5 n).val : ℤ)) := congrArg (U ^ ·) he
      _ = (U ^ (5 : ℤ)) ^ (n / 5) * U ^ ((residue5 n).val : ℤ) := by
        rw [zpow_add, zpow_mul]
      _ = _ := by simp only [zpow_natCast, zpow_ofNat]
  rw [hp, Units.val_mul, Units.val_zpow_eq_zpow_val,
    Units.val_pow_eq_pow_val, hU, ← map_zpow₀]
  rfl

variable (b : Basis (Fin 5 × Fin 5) K A) (U V : Aˣ) (x y : K)
variable (hb : ∀ ij, b ij = (U : A) ^ ij.1.val * (V : A) ^ ij.2.val)
variable (hU : (U : A) ^ 5 = algebraMap K A x)
variable (hV : (V : A) ^ 5 = algebraMap K A y)

include hb hU hV

theorem normalize_monomial (i j : ℤ) :
    ((U ^ i : Aˣ) : A) * ((V ^ j : Aˣ) : A) =
      (x ^ (i / 5) * y ^ (j / 5)) • b (residue5 i, residue5 j) := by
  rw [normalize_zpow U x hU, normalize_zpow V y hV, hb]
  simp only [Algebra.smul_def, map_mul]
  calc
    (algebraMap K A (x ^ (i / 5)) * (U : A) ^ (residue5 i).val) *
        (algebraMap K A (y ^ (j / 5)) * (V : A) ^ (residue5 j).val) =
      algebraMap K A (x ^ (i / 5)) *
        ((U : A) ^ (residue5 i).val * algebraMap K A (y ^ (j / 5))) *
        (V : A) ^ (residue5 j).val := by simp only [mul_assoc]
    _ = _ := by
      rw [(Algebra.commutes (y ^ (j / 5)) ((U : A) ^ (residue5 i).val)).symm]
      simp only [mul_assoc]

def termCoordinate (q x y : K) (ij : Fin 5 × Fin 5) (t : Term) : K :=
  if (residue5 t.1.1, residue5 t.1.2) = ij then
    evalCoeff q t.2 * (x ^ (t.1.1 / 5) * y ^ (t.1.2 / 5)) else 0

theorem repr_evalTerm (q : K) (t : Term) (ij : Fin 5 × Fin 5) :
    b.repr (evalTerm q U V t) ij = termCoordinate q x y ij t := by
  rw [evalTerm_eq, Units.val_mul, normalize_monomial b U V x y hb hU hV]
  rw [← Algebra.smul_def, smul_smul]
  simp [termCoordinate, Finsupp.single_apply]

theorem repr_evalLaurent (q : K) (p : List Term) (ij : Fin 5 × Fin 5) :
    b.repr (evalLaurent q U V p) ij = (p.map (termCoordinate q x y ij)).sum := by
  induction p with
  | nil => simp [evalLaurent]
  | cons t p ih =>
    change b.repr (evalTerm q U V t + evalLaurent q U V p) ij = _
    rw [map_add, Finsupp.add_apply, repr_evalTerm b U V x y hb hU hV, ih]
    rfl

end ConcreteCoordinateBridge
