/- Structural consequences of the explicit relative symbol-family data. -/
module
public import FamilyInterface

@[expose] public section
noncomputable section
open Module
namespace PrimeFiveFamily
variable {K A : Type*} [Field K] [CharZero K] [DivisionRing A] [Algebra K A]
variable (s : SymbolFamily K A)

theorem q_pow_ten : s.q ^ 10 = 1 := by
  calc
    s.q ^ 10 = (s.q ^ 5) ^ 2 := by rw [← pow_mul]
    _ = 1 := by rw [s.q_primitive.pow_eq_one]; simp

theorem fifth_VU : ((s.V : A) * s.U) ^ 5 = algebraMap K A (s.x * s.y) := by
  rw [TwoCoefficientObstruction.skew_mul_fifth s.q (s.V : A) (s.U : A) s.quantum,
    q_pow_ten, one_smul, s.fifth_V, s.fifth_U, ← map_mul, mul_comm s.y s.x]

theorem fifth_UV : ((s.U : A) * s.V) ^ 5 = algebraMap K A (s.x * s.y) := by
  calc
    ((s.U : A) * s.V) ^ 5 = (s.q • ((s.V : A) * s.U)) ^ 5 :=
      congrArg (fun a : A => a ^ 5) s.quantum
    _ = s.q ^ 5 • (((s.V : A) * s.U) ^ 5) := smul_pow _ _ _
    _ = algebraMap K A (s.x * s.y) := by
      rw [s.q_primitive.pow_eq_one, one_smul, fifth_VU]

theorem fifth_W : W s ^ 5 = algebraMap K A (z s) := by
  rw [W, inv_pow, fifth_UV, ← map_inv₀]
  rfl

theorem tau_x : s.tau s.x = s.y := by
  apply (algebraMap K A).injective
  calc
    algebraMap K A (s.tau s.x) = s.sigma (algebraMap K A s.x) := (sigma_scalar s s.x).symm
    _ = s.sigma ((s.U : A) ^ 5) := congrArg s.sigma s.fifth_U.symm
    _ = (s.V : A) ^ 5 := by rw [map_pow, s.sigma_U]
    _ = algebraMap K A s.y := s.fifth_V

theorem tau_y : s.tau s.y = z s := by
  apply (algebraMap K A).injective
  calc
    algebraMap K A (s.tau s.y) = s.sigma (algebraMap K A s.y) := (sigma_scalar s s.y).symm
    _ = s.sigma ((s.V : A) ^ 5) := congrArg s.sigma s.fifth_V.symm
    _ = W s ^ 5 := by rw [map_pow, s.sigma_V]; rfl
    _ = algebraMap K A (z s) := fifth_W s

theorem tau_z : s.tau (z s) = s.x := by
  apply (algebraMap K A).injective
  calc
    algebraMap K A (s.tau (z s)) = s.sigma (algebraMap K A (z s)) :=
      (sigma_scalar s (z s)).symm
    _ = s.sigma (W s ^ 5) := congrArg s.sigma (fifth_W s).symm
    _ = (s.U : A) ^ 5 := by rw [map_pow, sigma_W]
    _ = algebraMap K A s.x := s.fifth_U

theorem x_ne_y : s.x ≠ s.y :=
  TwoCoefficientObstruction.quantum_fifth_powers_ne s.q s.q_primitive
    s.U s.V s.quantum s.x s.y s.fifth_U s.fifth_V

/-- Derived dimension; it is not an input to SymbolFamily. -/
theorem fixed_finrank : Module.finrank (FixedScalars s) (FixedAlgebra s) = 25 :=
  C3BasisDescent.finrank_fixedAlgebra_twentyFive s.basis s.sigma s.tau s.semilinear
    s.sigma_cube s.x s.y (z s) (tau_x s) (tau_y s) (tau_z s) (x_ne_y s)

@[implicit_reducible]
def fixedDivisionRing : DivisionRing (FixedAlgebra s) :=
  C3BasisDescent.fixedDivisionRing s.basis s.sigma s.tau s.semilinear
    s.sigma_cube s.x s.y (z s) (tau_x s) (tau_y s) (tau_z s) (x_ne_y s)

/-- Derived center characterization in the actual fixed subalgebra. -/
theorem fixed_center (d : FixedAlgebra s) :
    (∀ e : FixedAlgebra s, d * e = e * d) ↔
      ∃ c : FixedScalars s, algebraMap (FixedScalars s) (FixedAlgebra s) c = d := by
  exact (C3BasisDescent.degreeFive_descent s.basis s.sigma s.tau s.semilinear
    s.sigma_cube s.x s.y (z s) (tau_x s) (tau_y s) (tau_z s) (x_ne_y s) s.center).2 d

/- REMAINING CONCRETE OBLIGATION (not an axiom or structure field):

The full N^5 kernel certificate and its semantic evaluation must prove
  ∃ a : K, frozenNumerator s ^ 5 = algebraMap K A a.

FamilyInterface now proves the actual frozen/compact equality, fixedness, and
non-scalarity. PowerInterface prepares the exact scalar-unit hypotheses required
by the quantum-Laurent certificate, and lifts any subsequently proved fifth-power
identity to the fixed field. SupportingEndpoint checks the endpoint application
under that explicit identity hypothesis; it is intentionally a supporting
conditional theorem, not the requested complete family theorem.

A final theorem with no additional numerator/power hypotheses may be declared
only after the full identity and 5-divisible-support certificate are imported.
-/
end PrimeFiveFamily
