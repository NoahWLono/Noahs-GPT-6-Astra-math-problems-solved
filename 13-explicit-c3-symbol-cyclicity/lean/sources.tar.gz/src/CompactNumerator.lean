module
public import PairInvariance
public import Mathlib.Algebra.Field.Basic
public import Mathlib.Algebra.GroupWithZero.Units.Lemmas
public import Mathlib.Data.Nat.Cast.Basic

/- No expanded-candidate equality is asserted. -/
@[expose] public section
namespace CompactC3Invariance
variable {D : Type*} [DivisionRing D]

def differencePair (U V W : D) : Pair D := (U - W, V - W)
def inversePair (U V W : D) : Pair D := (U⁻¹ - W⁻¹, V⁻¹ - W⁻¹)
def scalarPair (x y z : D) : Pair D := (x - y, z - y)
def coefficient (q : D) : D := 5 * (1 + q⁻¹)
def compactNumerator (q U V W : D) : D :=
  pairing (scalarPair (U ^ 5) (V ^ 5) (W ^ 5))
    (covariant (coefficient q) (differencePair U V W) (inversePair U V W))

theorem differencePair_covariance (σ : D ≃+* D) (U V W : D)
    (hU : σ U = V) (hV : σ V = W) (hW : σ W = U) :
    pairMap σ (differencePair U V W) = T (differencePair U V W) := by
  apply Prod.ext <;> simp only [pairMap, differencePair, T, map_sub, hU, hV, hW]
    <;> noncomm_ring

theorem inversePair_covariance (σ : D ≃+* D) (U V W : D)
    (hU : σ U = V) (hV : σ V = W) (hW : σ W = U) :
    pairMap σ (inversePair U V W) = T (inversePair U V W) := by
  apply Prod.ext <;> simp only [pairMap, inversePair, T, map_sub, map_inv₀, hU, hV, hW]
    <;> noncomm_ring

theorem scalarPair_covariance (σ : D ≃+* D) (x y z : D)
    (hx : σ x = y) (hy : σ y = z) (hz : σ z = x) :
    pairMap σ (scalarPair x y z) = S (scalarPair x y z) := by
  apply Prod.ext <;> simp only [pairMap, scalarPair, S, map_sub, hx, hy, hz]
    <;> noncomm_ring

/-- Fixedness of the compact expression follows from the actual cyclic automorphism.
Neither a power identity nor equality with a chosen expanded numerator is assumed. -/
theorem compactNumerator_fixed (σ : D ≃+* D) (q U V W : D)
    (hq : σ q = q) (hU : σ U = V) (hV : σ V = W) (hW : σ W = U) :
    σ (compactNumerator q U V W) = compactNumerator q U V W := by
  apply compact_fixed_of_covariance
  · simp [coefficient, hq, map_ofNat]
  · exact differencePair_covariance σ U V W hU hV hW
  · exact inversePair_covariance σ U V W hU hV hW
  · exact scalarPair_covariance σ (U ^ 5) (V ^ 5) (W ^ 5)
      (by simp [hU]) (by simp [hV]) (by simp [hW])

/-- When W=(UV)⁻¹ and U,V are nonzero, the third generator cycle is derived. -/
theorem compactNumerator_fixed_of_two_images (σ : D ≃+* D) (q U V : D)
    (hU0 : U ≠ 0) (hV0 : V ≠ 0) (hq : σ q = q)
    (hU : σ U = V) (hV : σ V = (U * V)⁻¹) :
    σ (compactNumerator q U V (U * V)⁻¹) = compactNumerator q U V (U * V)⁻¹ := by
  apply compactNumerator_fixed σ q U V (U * V)⁻¹ hq hU hV
  simp only [map_inv₀, map_mul, hU, hV, mul_inv_rev]
  simp [hU0, hV0]

#print axioms compactNumerator_fixed
#print axioms compactNumerator_fixed_of_two_images
#print compactNumerator_fixed_of_two_images
end CompactC3Invariance
