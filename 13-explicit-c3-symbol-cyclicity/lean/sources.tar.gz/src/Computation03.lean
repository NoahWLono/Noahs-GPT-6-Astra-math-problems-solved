module
public import Computation02
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
namespace CompactLaurentBridge
open PrimeCyclicity
variable {K D : Type*} [CommRing K] [DivisionRing D] [Algebra K D]
    (q : K) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap K D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
def p_bd : List Term := [
  (((Int.negSucc 4), (Int.negSucc 3)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 3), (Int.negSucc 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 2), (Int.negSucc 2)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 1), (Int.negSucc 0)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.negSucc 1), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 1)), ((Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.negSucc 0), (Int.ofNat 4)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 0), (Int.ofNat 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.ofNat 3)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.negSucc 0)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 2)), ((Int.negSucc 1), (Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 5)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.ofNat 3), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 3), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem p_bd_certificate : fastMul ac1 b0 = p_bd := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_p_bd : evalLaurent q U V p_bd = evalLaurent q U V ac1 * evalLaurent q U V b0 := by
  rw [← p_bd_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def p_0 : List Term := [
  (((Int.negSucc 4), (Int.negSucc 3)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 3), (Int.negSucc 4)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 2), (Int.negSucc 2)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.negSucc 2), (Int.ofNat 0)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 1), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.negSucc 1), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.negSucc 1)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 1)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.negSucc 2)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 1), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 5)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.ofNat 2), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 3), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.ofNat 2)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.ofNat 1)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem p_0_certificate : subL p_ad p_be = p_0 := by decide +kernel
theorem eval_p_0 : evalLaurent q U V p_0 = evalLaurent q U V p_ad - evalLaurent q U V p_be := by
  rw [← p_0_certificate, eval_sub q U V]
def p_sum : List Term := [
  (((Int.negSucc 4), (Int.negSucc 3)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 3), (Int.negSucc 4)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 3), (Int.negSucc 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 2), (Int.negSucc 2)), ((Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.negSucc 1), (Int.negSucc 3)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.negSucc 1), (Int.negSucc 0)), ((Int.ofNat 1), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 1), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.negSucc 1)), ((Int.negSucc 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.negSucc 0), (Int.ofNat 4)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 0), (Int.ofNat 0)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 2))),
  (((Int.ofNat 0), (Int.ofNat 3)), ((Int.ofNat 0), (Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 1), (Int.ofNat 2)), ((Int.negSucc 1), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 5)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 2), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 1))),
  (((Int.ofNat 2), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 3), (Int.ofNat 0)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 3), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.negSucc 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.ofNat 1)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem p_sum_certificate : addL p_ae p_bd = p_sum := by decide +kernel
theorem eval_p_sum : evalLaurent q U V p_sum = evalLaurent q U V p_ae + evalLaurent q U V p_bd := by
  rw [← p_sum_certificate, eval_add q U V]
def p_1 : List Term := [
  (((Int.negSucc 4), (Int.negSucc 3)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 3), (Int.negSucc 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 2), (Int.negSucc 2)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 1), (Int.negSucc 3)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.negSucc 1), (Int.negSucc 0)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 1), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 4)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 0), (Int.negSucc 2)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.ofNat 3)), ((Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 1), (Int.ofNat 2)), ((Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 2), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 3), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 2), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 3), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.negSucc 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.ofNat 1)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem p_1_certificate : subL p_sum p_be = p_1 := by decide +kernel
theorem eval_p_1 : evalLaurent q U V p_1 = evalLaurent q U V p_sum - evalLaurent q U V p_be := by
  rw [← p_1_certificate, eval_sub q U V]
def d0 : List Term := [
  (((Int.ofNat 0), (Int.ofNat 5)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem d0_certificate : subL x y = d0 := by decide +kernel
theorem eval_d0 : evalLaurent q U V d0 = evalLaurent q U V x - evalLaurent q U V y := by
  rw [← d0_certificate, eval_sub q U V]
def d1 : List Term := [
  (((Int.negSucc 4), (Int.negSucc 4)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.ofNat 5)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem d1_certificate : subL z y = d1 := by decide +kernel
theorem eval_d1 : evalLaurent q U V d1 = evalLaurent q U V z - evalLaurent q U V y := by
  rw [← d1_certificate, eval_sub q U V]
def d0twice : List Term := [
  (((Int.ofNat 0), (Int.ofNat 5)), ((Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.ofNat 0)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem d0twice_certificate : addL d0 d0 = d0twice := by decide +kernel
theorem eval_d0twice : evalLaurent q U V d0twice = evalLaurent q U V d0 + evalLaurent q U V d0 := by
  rw [← d0twice_certificate, eval_add q U V]
def e0 : List Term := [
  (((Int.negSucc 4), (Int.negSucc 4)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.ofNat 5)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.ofNat 0)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem e0_certificate : subL d0twice d1 = e0 := by decide +kernel
theorem eval_e0 : evalLaurent q U V e0 = evalLaurent q U V d0twice - evalLaurent q U V d1 := by
  rw [← e0_certificate, eval_sub q U V]
def d1twice : List Term := [
  (((Int.negSucc 4), (Int.negSucc 4)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.ofNat 5)), ((Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem d1twice_certificate : addL d1 d1 = d1twice := by decide +kernel
theorem eval_d1twice : evalLaurent q U V d1twice = evalLaurent q U V d1 + evalLaurent q U V d1 := by
  rw [← d1twice_certificate, eval_add q U V]
def e1 : List Term := [
  (((Int.negSucc 4), (Int.negSucc 4)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.ofNat 5)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.ofNat 0)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem e1_certificate : subL d1twice d0 = e1 := by decide +kernel
theorem eval_e1 : evalLaurent q U V e1 = evalLaurent q U V d1twice - evalLaurent q U V d0 := by
  rw [← e1_certificate, eval_sub q U V]
def n0 : List Term := [
  (((Int.negSucc 9), (Int.negSucc 8)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 8), (Int.negSucc 9)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 7), (Int.negSucc 7)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.negSucc 7), (Int.negSucc 4)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.negSucc 6), (Int.negSucc 5)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 6), (Int.negSucc 2)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 5), (Int.negSucc 6)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 5), (Int.negSucc 3)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 4), (Int.negSucc 7)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 4), (Int.negSucc 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 4), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 3), (Int.negSucc 5)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 3), (Int.negSucc 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 3), (Int.ofNat 0)), ((Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 2), (Int.negSucc 6)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.negSucc 2), (Int.negSucc 3)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 2), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.negSucc 2), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.negSucc 2), (Int.ofNat 5)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.negSucc 1), (Int.negSucc 4)), ((Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 1), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 1), (Int.ofNat 7)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.negSucc 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 3)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 6)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.negSucc 3)), ((Int.ofNat 1), (Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.ofNat 2)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 0), (Int.ofNat 8)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 1), (Int.negSucc 4)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 4)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 7)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 10)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 2)), ((Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 2))),
  (((Int.ofNat 2), (Int.ofNat 0)), ((Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.ofNat 2), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 2), (Int.ofNat 6)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.ofNat 9)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.ofNat 3), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 3), (Int.ofNat 2)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 3), (Int.ofNat 5)), ((Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.negSucc 1)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.ofNat 1)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.ofNat 7)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.negSucc 2)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 5), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 5), (Int.ofNat 6)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 6), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 0))),
  (((Int.ofNat 6), (Int.ofNat 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0))),
  (((Int.ofNat 6), (Int.ofNat 5)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 7), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 1))),
  (((Int.ofNat 7), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 7), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 2))),
  (((Int.ofNat 8), (Int.ofNat 0)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 9), (Int.ofNat 2)), ((Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 10), (Int.ofNat 1)), ((Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem n0_certificate : fastMul e0 p_0 = n0 := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_n0 : evalLaurent q U V n0 = evalLaurent q U V e0 * evalLaurent q U V p_0 := by
  rw [← n0_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def n1 : List Term := [
  (((Int.negSucc 9), (Int.negSucc 8)), ((Int.ofNat 0), (Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 8), (Int.negSucc 6)), ((Int.ofNat 0), (Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 7), (Int.negSucc 7)), ((Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1), (Int.ofNat 0))),
  (((Int.negSucc 6), (Int.negSucc 8)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 1))),
  (((Int.negSucc 6), (Int.negSucc 5)), ((Int.ofNat 0), (Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 6), (Int.negSucc 2)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 5), (Int.negSucc 6)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 0))),
  (((Int.negSucc 5), (Int.negSucc 3)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0))),
  (((Int.negSucc 5), (Int.negSucc 0)), ((Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.negSucc 4), (Int.negSucc 7)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.negSucc 4), (Int.negSucc 1)), ((Int.negSucc 1), (Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 4), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 3), (Int.negSucc 5)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.negSucc 3), (Int.negSucc 2)), ((Int.negSucc 1), (Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 3), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 2), (Int.negSucc 3)), ((Int.ofNat 0), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.negSucc 2), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 2))),
  (((Int.negSucc 2), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.negSucc 1), (Int.negSucc 4)), ((Int.ofNat 2), (Int.ofNat 4), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.negSucc 1), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 1), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.negSucc 1), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 1), (Int.ofNat 7)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.negSucc 5)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 3)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 6)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 9)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.negSucc 3)), ((Int.negSucc 1), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.ofNat 2)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 0), (Int.ofNat 8)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 4)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 1), (Int.ofNat 7)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 2)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.ofNat 6)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 2), (Int.ofNat 9)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.ofNat 3), (Int.negSucc 3)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 3), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 3), (Int.ofNat 2)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 3), (Int.ofNat 5)), ((Int.negSucc 0), (Int.negSucc 1), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 3), (Int.ofNat 8)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.negSucc 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 5), (Int.negSucc 2)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 5), (Int.ofNat 3)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.ofNat 6)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 6), (Int.negSucc 0)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 6), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 7), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 7), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.ofNat 8), (Int.ofNat 0)), ((Int.negSucc 0), (Int.negSucc 1), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 8), (Int.ofNat 3)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 9), (Int.negSucc 0)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 10), (Int.ofNat 1)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem n1_certificate : fastMul e1 p_1 = n1 := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_n1 : evalLaurent q U V n1 = evalLaurent q U V e1 * evalLaurent q U V p_1 := by
  rw [← n1_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def result : List Term := [
  (((Int.negSucc 9), (Int.negSucc 8)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 8), (Int.negSucc 9)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 8), (Int.negSucc 6)), ((Int.ofNat 0), (Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 7), (Int.negSucc 7)), ((Int.negSucc 0), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 0))),
  (((Int.negSucc 7), (Int.negSucc 4)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.negSucc 6), (Int.negSucc 8)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 1))),
  (((Int.negSucc 6), (Int.negSucc 5)), ((Int.ofNat 0), (Int.negSucc 1), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 6), (Int.negSucc 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 5), (Int.negSucc 6)), ((Int.negSucc 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.negSucc 5), (Int.negSucc 3)), ((Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.negSucc 5), (Int.negSucc 0)), ((Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.negSucc 4), (Int.negSucc 7)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.negSucc 4), (Int.negSucc 1)), ((Int.negSucc 1), (Int.negSucc 2), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 4), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 3), (Int.negSucc 5)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 2))),
  (((Int.negSucc 3), (Int.negSucc 2)), ((Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 3), (Int.ofNat 0)), ((Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 3), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 2), (Int.negSucc 6)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.negSucc 2), (Int.negSucc 3)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.negSucc 2), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.negSucc 2), (Int.ofNat 2)), ((Int.ofNat 2), (Int.ofNat 1), (Int.ofNat 1), (Int.negSucc 0))),
  (((Int.negSucc 2), (Int.ofNat 5)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.negSucc 1), (Int.negSucc 4)), ((Int.ofNat 1), (Int.ofNat 3), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.negSucc 1), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 1), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.negSucc 1), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 1), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 1), (Int.ofNat 7)), ((Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.negSucc 5)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.negSucc 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 3)), ((Int.negSucc 0), (Int.negSucc 1), (Int.negSucc 1), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 6)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 1), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 9)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.negSucc 3)), ((Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.ofNat 2)), ((Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.ofNat 0), (Int.ofNat 8)), ((Int.ofNat 1), (Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 1), (Int.negSucc 4)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 4)), ((Int.ofNat 0), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 0))),
  (((Int.ofNat 1), (Int.ofNat 7)), ((Int.ofNat 1), (Int.ofNat 1), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 10)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 2)), ((Int.negSucc 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 2))),
  (((Int.ofNat 2), (Int.ofNat 0)), ((Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.ofNat 2), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 2), (Int.ofNat 6)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 2), (Int.ofNat 9)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 1))),
  (((Int.ofNat 3), (Int.negSucc 3)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 3), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 3), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 3), (Int.ofNat 5)), ((Int.negSucc 1), (Int.negSucc 2), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 3), (Int.ofNat 8)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.negSucc 1)), ((Int.ofNat 2), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.ofNat 1)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 4), (Int.ofNat 7)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.negSucc 2)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 5), (Int.ofNat 3)), ((Int.ofNat 1), (Int.ofNat 3), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 5), (Int.ofNat 6)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 6), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.negSucc 0))),
  (((Int.ofNat 6), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 2), (Int.ofNat 0))),
  (((Int.ofNat 6), (Int.ofNat 5)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 7), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 1))),
  (((Int.ofNat 7), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 7), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 8), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 8), (Int.ofNat 3)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 9), (Int.negSucc 0)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 9), (Int.ofNat 2)), ((Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 10), (Int.ofNat 1)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem result_certificate : addL n0 n1 = result := by decide +kernel
theorem eval_result : evalLaurent q U V result = evalLaurent q U V n0 + evalLaurent q U V n1 := by
  rw [← result_certificate, eval_add q U V]
theorem result_eq_numerator : result = numerator := by decide +kernel
#print axioms result_eq_numerator
end CompactLaurentBridge
