/- Elementary fixed-basis descent. No trace, tensor, or Galois theory. -/
module

public import Mathlib.LinearAlgebra.Basis.VectorSpace
public import Mathlib.LinearAlgebra.Basis.Submodule
public import Mathlib.LinearAlgebra.FiniteDimensional.Defs

@[expose] public section
noncomputable section
open Module Submodule

namespace C3BasisDescent

variable {F K A : Type*} [Field F] [Field K] [Algebra F K]
  [Ring A] [Algebra F A] [Algebra K A] [IsScalarTower F K A]
  (σ : A ≃+* A) (τ : K ≃+* K)
  (hsemi : ∀ (c : K) (a : A), σ (c • a) = τ c • σ a)

include hsemi in
/-- Coordinatewise action for a finite basis whose vectors are fixed. -/
theorem repr_sigma {ι : Type*} [Fintype ι] (b : Basis ι K A)
    (hb : ∀ i, σ (b i) = b i) (a : A) (i : ι) :
    b.repr (σ a) i = τ (b.repr a i) := by
  classical
  have hexp : σ a = ∑ j, τ (b.repr a j) • b j := by
    conv_lhs => rw [← b.sum_repr a]
    simp only [map_sum, hsemi, hb]
  rw [hexp]
  exact congrFun (b.repr_sum_self (fun j => τ (b.repr a j))) i

variable (S : Submodule F A)
  (hS : ∀ a : A, a ∈ S ↔ σ a = a)
  (hF : ∀ c : K, τ c = c ↔ c ∈ Set.range (algebraMap F K))

include hsemi hS hF in
/-- The fixed subspace is the F-span of any fixed K-basis. -/
theorem fixed_eq_span {ι : Type*} [Fintype ι] (b : Basis ι K A)
    (hb : ∀ i, σ (b i) = b i) : S = span F (Set.range b) := by
  apply le_antisymm
  · intro a ha
    apply (b.mem_span_iff_repr_mem F a).mpr
    intro i
    apply (hF _).mp
    have h := repr_sigma σ τ hsemi b hb a i
    rw [(hS a).mp ha] at h
    exact h.symm
  · apply span_le.mpr
    rintro a ⟨i, rfl⟩
    exact (hS (b i)).mpr (hb i)

/-- Explicit F-basis obtained by restricting the scalars of a fixed K-basis. -/
def fixedBasis {ι : Type*} [Fintype ι] (b : Basis ι K A)
    (hb : ∀ i, σ (b i) = b i) : Basis ι F S :=
  (b.restrictScalars F).map
    (LinearEquiv.ofEq _ _ (fixed_eq_span σ τ hsemi S hS hF b hb).symm)

include hsemi hS hF in
/-- K-span of fixed elements suffices for equality of dimensions. -/
theorem finrank_fixed_eq [FiniteDimensional K A]
    (hspan : span K {a : A | σ a = a} = ⊤) :
    Module.finrank F S = Module.finrank K A := by
  classical
  let b := Basis.ofSpan (show ⊤ ≤ span K {a : A | σ a = a} from hspan.ge)
  letI := FiniteDimensional.fintypeBasisIndex b
  have hb : ∀ i, σ (b i) = b i := by
    intro i
    exact Basis.ofSpan_subset (show ⊤ ≤ span K {a : A | σ a = a} from hspan.ge)
      (Set.mem_range_self i)
  let bF := fixedBasis σ τ hsemi S hS hF b hb
  rw [Module.finrank_eq_card_basis bF, Module.finrank_eq_card_basis b]

end C3BasisDescent
