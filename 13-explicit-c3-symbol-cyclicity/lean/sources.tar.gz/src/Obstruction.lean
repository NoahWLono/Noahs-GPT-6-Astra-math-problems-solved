module
public import ScalarEquations

@[expose] public section
namespace TwoCoefficientObstruction
variable {F D : Type*} [Field F] [DivisionRing D] [Algebra F D]

/-- Scalar fifth powers of quantum generators cannot be equal. -/
theorem quantum_fifth_powers_ne (q : F) (hq : IsPrimitiveRoot q 5)
    (U V : Dˣ) (hUV : (U : D) * V = q • ((V : D) * U))
    (x y : F) (hU : (U : D) ^ 5 = algebraMap F D x)
    (hV : (V : D) ^ 5 = algebraMap F D y) : x ≠ y := by
  intro hxy
  have hskew : (V : D)⁻¹ * U = q • ((U : D) * (V : D)⁻¹) := by
    calc
      (V : D)⁻¹ * U = (V : D)⁻¹ * ((U : D) * V) * (V : D)⁻¹ := by
        simp [mul_assoc]
      _ = (V : D)⁻¹ * (q • ((V : D) * U)) * (V : D)⁻¹ := by rw [hUV]
      _ = q • ((U : D) * (V : D)⁻¹) := by
        simp
  have hphase : q ^ 10 = 1 := by
    calc
      q ^ 10 = (q ^ 5) ^ 2 := by rw [← pow_mul]
      _ = 1 := by rw [hq.pow_eq_one]; simp
  have hroot : ((U : D) * (V : D)⁻¹) ^ 5 = 1 := by
    rw [skew_mul_fifth q (U : D) (V : D)⁻¹ hskew, hphase, one_smul]
    rw [inv_pow, hU, hV, hxy, ← hV]
    simp
  obtain ⟨i, hi, hiw⟩ := PrimeCyclicityEndpoint.fifth_root_is_scalar_power F D q hq
    ((U : D) * (V : D)⁻¹) hroot
  have hscalar : (U : D) = algebraMap F D (q ^ i) * V := by
    calc
      (U : D) = ((U : D) * (V : D)⁻¹) * V := by simp
      _ = algebraMap F D (q ^ i) * V := by rw [hiw]
  have hcomm : Commute (U : D) (V : D) := by
    rw [hscalar]
    exact (show Commute (algebraMap F D (q ^ i)) (V : D) from
      Algebra.commutes (q ^ i) (V : D)).mul_left (Commute.refl (V : D))
  have hmap : algebraMap F D q = 1 := by
    apply mul_right_cancel₀ (mul_ne_zero V.ne_zero U.ne_zero)
    simpa [Algebra.smul_def] using hUV.symm.trans hcomm.eq
  have heq : q = 1 := (algebraMap F D).injective (by simpa using hmap)
  exact hq.ne_one (by decide) heq

/-- Abstract two-coefficient obstruction only: no claim that these equations arise
from a particular numerator, normal form, basis, or concrete generic family. -/
theorem two_coefficient_equations_impossible [CharZero F]
    (q : F) (hq : IsPrimitiveRoot q 5) (U V : Dˣ)
    (hUV : (U : D) * V = q • ((V : D) * U))
    (x y : F) (hU : (U : D) ^ 5 = algebraMap F D x)
    (hV : (V : D) ^ 5 = algebraMap F D y)
    (h₁ : x ^ 2 * y + x * y ^ 2 = 2)
    (h₂ : 2 * x ^ 2 * y - x * y ^ 2 = 1) : False := by
  exact quantum_fifth_powers_ne q hq U V hUV x y hU hV
    (scalar_equations_force_equal x y h₁ h₂).1

#print axioms quantum_fifth_powers_ne
#print axioms two_coefficient_equations_impossible
#print two_coefficient_equations_impossible
end TwoCoefficientObstruction
