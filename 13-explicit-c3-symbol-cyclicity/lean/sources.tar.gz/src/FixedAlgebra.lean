module
public import BasisDescent
public import Mathlib.Algebra.Algebra.Subalgebra.Basic
public import Interpolation
public import Mathlib.Algebra.Field.Subfield.Basic

@[expose] public section
noncomputable section
open Module Submodule

namespace C3BasisDescent
variable {K A : Type*} [Field K] [Ring A] [Algebra K A]

/-- The scalar field fixed by the actual scalar automorphism. -/
def fixedField (τ : K ≃+* K) : Subfield K :=
  τ.toRingHom.eqLocusField (RingHom.id K)

instance (priority := 100) fixedFieldAlgebra (τ : K ≃+* K) : Algebra (fixedField τ) A :=
  Algebra.compHom A (fixedField τ).subtype

instance fixedFieldTower (τ : K ≃+* K) : IsScalarTower (fixedField τ) K A where
  smul_assoc c k a := by
    change ((c : K) * k) • a = (c : K) • (k • a)
    exact mul_smul _ _ _

theorem fixedField_spec (τ : K ≃+* K) (c : K) :
    τ c = c ↔ c ∈ Set.range (algebraMap (fixedField τ) K) := by
  constructor
  · intro hc
    exact ⟨⟨c, hc⟩, rfl⟩
  · rintro ⟨c, rfl⟩
    exact c.property

/-- The actual fixed algebra, rather than an abstract dimension-bearing structure. -/
def fixedAlgebra (σ : A ≃+* A) (τ : K ≃+* K)
    (hsemi : ∀ (c : K) (a : A), σ (c • a) = τ c • σ a) :
    Subalgebra (fixedField τ) A where
  carrier := {a | σ a = a}
  zero_mem' := map_zero σ
  one_mem' := map_one σ
  add_mem' := fun ha hb => (map_add σ _ _).trans (congrArg₂ (· + ·) ha hb)
  mul_mem' := fun ha hb => (map_mul σ _ _).trans (congrArg₂ (· * ·) ha hb)
  algebraMap_mem' c := by
    change σ (algebraMap K A (c : K)) = algebraMap K A (c : K)
    have hc : τ (c : K) = c := c.property
    simpa only [Algebra.smul_def, mul_one, map_one, hc] using hsemi (c : K) (1 : A)

/-- Descent dimension follows from fixed-vector spanning alone. -/
theorem finrank_fixedAlgebra [FiniteDimensional K A]
    (σ : A ≃+* A) (τ : K ≃+* K)
    (hsemi : ∀ (c : K) (a : A), σ (c • a) = τ c • σ a)
    (hspan : span K {a : A | σ a = a} = ⊤) :
    Module.finrank (fixedField τ) (fixedAlgebra σ τ hsemi) = Module.finrank K A := by
  exact finrank_fixed_eq σ τ hsemi (fixedAlgebra σ τ hsemi).toSubmodule
    (fun _ => Iff.rfl) (fixedField_spec τ) hspan

/-- Concrete three-cycle interpolation supplies the spanning hypothesis. -/
theorem finrank_fixedAlgebra_of_cycle [FiniteDimensional K A]
    (σ : A ≃+* A) (τ : K ≃+* K)
    (hsemi : ∀ (c : K) (a : A), σ (c • a) = τ c • σ a)
    (horder : ∀ a : A, σ (σ (σ a)) = a)
    (x y z : K) (hx : τ x = y) (hy : τ y = z) (hz : τ z = x) (hxy : x ≠ y) :
    Module.finrank (fixedField τ) (fixedAlgebra σ τ hsemi) = Module.finrank K A := by
  exact finrank_fixedAlgebra σ τ hsemi
    (C3Interpolation.span_fixed_eq_top_of_cycle σ τ hsemi horder x y z hx hy hz hxy)

end C3BasisDescent
