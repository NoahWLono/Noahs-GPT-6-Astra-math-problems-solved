module
public import Mathlib.Algebra.Algebra.Basic
public import Mathlib.LinearAlgebra.Span.Basic
public import Mathlib.Tactic.Module

@[expose] public section
namespace C3Interpolation
variable {K A : Type*} [Field K] [Ring A] [Algebra K A]

def trace0 (σ : A ≃+* A) (a : A) : A := a + σ a + σ (σ a)
def trace1 (σ : A ≃+* A) (x y z : K) (a : A) : A :=
  x • a + y • σ a + z • σ (σ a)
def trace2 (σ : A ≃+* A) (x y z : K) (a : A) : A :=
  x ^ 2 • a + y ^ 2 • σ a + z ^ 2 • σ (σ a)

/-- Fixedness comes from the actual automorphism and its order-three action. -/
theorem trace0_fixed (σ : A ≃+* A) (horder : ∀ a : A, σ (σ (σ a)) = a) (a : A) :
    σ (trace0 σ a) = trace0 σ a := by
  simp only [trace0, map_add, horder]
  simp only [add_comm, add_left_comm, add_assoc]

theorem trace1_fixed (σ : A ≃+* A) (τ : K ≃+* K)
    (hsemi : ∀ k : K, ∀ a : A, σ (k • a) = τ k • σ a)
    (horder : ∀ a : A, σ (σ (σ a)) = a)
    (x y z : K) (hx : τ x = y) (hy : τ y = z) (hz : τ z = x) (a : A) :
    σ (trace1 σ x y z a) = trace1 σ x y z a := by
  simp only [trace1, map_add, hsemi, hx, hy, hz, horder]
  simp only [add_comm, add_left_comm, add_assoc]

theorem trace2_fixed (σ : A ≃+* A) (τ : K ≃+* K)
    (hsemi : ∀ k : K, ∀ a : A, σ (k • a) = τ k • σ a)
    (horder : ∀ a : A, σ (σ (σ a)) = a)
    (x y z : K) (hx : τ x = y) (hy : τ y = z) (hz : τ z = x) (a : A) :
    σ (trace2 σ x y z a) = trace2 σ x y z a := by
  simp only [trace2, map_add, hsemi, map_pow, hx, hy, hz, horder]
  simp only [add_comm, add_left_comm, add_assoc]

/-- Three-point interpolation eliminates the other two orbit vectors. -/
theorem interpolation_identity (σ : A ≃+* A) (x y z : K) (a : A) :
    trace2 σ x y z a - (y + z) • trace1 σ x y z a + (y * z) • trace0 σ a =
      ((x - y) * (x - z)) • a := by
  unfold trace0 trace1 trace2
  module

/-- With distinct orbit scalars, every vector is in the K-span of fixed elements. -/
theorem mem_span_fixed (σ : A ≃+* A) (τ : K ≃+* K)
    (hsemi : ∀ k : K, ∀ a : A, σ (k • a) = τ k • σ a)
    (horder : ∀ a : A, σ (σ (σ a)) = a)
    (x y z : K) (hx : τ x = y) (hy : τ y = z) (hz : τ z = x)
    (hxy : x ≠ y) (hxz : x ≠ z) (a : A) :
    a ∈ Submodule.span K {b : A | σ b = b} := by
  let S := Submodule.span K {b : A | σ b = b}
  have h0 : trace0 σ a ∈ S := Submodule.subset_span (trace0_fixed σ horder a)
  have h1 : trace1 σ x y z a ∈ S :=
    Submodule.subset_span (trace1_fixed σ τ hsemi horder x y z hx hy hz a)
  have h2 : trace2 σ x y z a ∈ S :=
    Submodule.subset_span (trace2_fixed σ τ hsemi horder x y z hx hy hz a)
  have hm : ((x - y) * (x - z)) • a ∈ S := by
    rw [← interpolation_identity σ x y z a]
    exact S.add_mem (S.sub_mem h2 (S.smul_mem _ h1)) (S.smul_mem _ h0)
  have hn : (x - y) * (x - z) ≠ 0 := mul_ne_zero (sub_ne_zero.mpr hxy) (sub_ne_zero.mpr hxz)
  have hc := S.smul_mem (((x - y) * (x - z))⁻¹) hm
  simpa only [smul_smul, inv_mul_cancel₀ hn, one_smul] using hc

/-- The fixed elements span A over K; no finite-dimensionality is assumed. -/
theorem span_fixed_eq_top (σ : A ≃+* A) (τ : K ≃+* K)
    (hsemi : ∀ k : K, ∀ a : A, σ (k • a) = τ k • σ a)
    (horder : ∀ a : A, σ (σ (σ a)) = a)
    (x y z : K) (hx : τ x = y) (hy : τ y = z) (hz : τ z = x)
    (hxy : x ≠ y) (hxz : x ≠ z) :
    Submodule.span K {b : A | σ b = b} = ⊤ := by
  apply top_unique
  intro a _
  exact mem_span_fixed σ τ hsemi horder x y z hx hy hz hxy hxz a

/-- For a cyclic orbit, x≠y already forces x≠z. -/
theorem span_fixed_eq_top_of_cycle (σ : A ≃+* A) (τ : K ≃+* K)
    (hsemi : ∀ k : K, ∀ a : A, σ (k • a) = τ k • σ a)
    (horder : ∀ a : A, σ (σ (σ a)) = a)
    (x y z : K) (hx : τ x = y) (hy : τ y = z) (hz : τ z = x)
    (hxy : x ≠ y) :
    Submodule.span K {b : A | σ b = b} = ⊤ := by
  apply span_fixed_eq_top σ τ hsemi horder x y z hx hy hz hxy
  intro heq
  have h : y = x := by simpa only [hx, hz] using congrArg τ heq
  exact hxy h.symm

#print axioms trace0_fixed
#print axioms trace1_fixed
#print axioms trace2_fixed
#print axioms interpolation_identity
#print axioms mem_span_fixed
#print axioms span_fixed_eq_top
#print axioms span_fixed_eq_top_of_cycle
end C3Interpolation
