module
public import Computation03

@[expose] public section
namespace CompactLaurentBridge
open PrimeCyclicity
variable {K D : Type*} [Field K] [DivisionRing D] [Algebra K D]
    (q : K) (U V : Dˣ)

theorem leaf_u : evalLaurent q U V u = (U : D) := by
  simp [u, evalLaurent, evalTerm, evalCoeff]
theorem leaf_v : evalLaurent q U V v = (V : D) := by
  simp [v, evalLaurent, evalTerm, evalCoeff]
theorem leaf_ui : evalLaurent q U V ui = (U : D)⁻¹ := by
  simp [ui, evalLaurent, evalTerm, evalCoeff]
theorem leaf_vi : evalLaurent q U V vi = (V : D)⁻¹ := by
  simp [vi, evalLaurent, evalTerm, evalCoeff]
theorem leaf_x : evalLaurent q U V x = (U : D) ^ 5 := by
  simp [x, evalLaurent, evalTerm, evalCoeff]
  exact zpow_natCast (U : D) 5
theorem leaf_y : evalLaurent q U V y = (V : D) ^ 5 := by
  simp [y, evalLaurent, evalTerm, evalCoeff]
  exact zpow_natCast (V : D) 5

theorem leaf_c (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1) :
    evalLaurent q U V c = CompactC3Invariance.coefficient (algebraMap K D q) := by
  have hq0 : q ≠ 0 := by intro h; simp [h] at h₅
  have hi : q ^ 4 = q⁻¹ := by
    apply mul_left_cancel₀ hq0
    rw [← pow_succ', h₅, mul_inv_cancel₀ hq0]
  have hc : evalCoeff q (Int.ofNat 0, Int.negSucc 4, Int.negSucc 4, Int.negSucc 4) = 5 * (1 + q ^ 4) := by
    rw [h₄]
    simp [evalCoeff]
    ring
  simp only [c, evalLaurent, List.map_cons, List.map_nil, List.sum_cons, List.sum_nil,
    evalTerm]
  rw [hc]
  simp [hi, CompactC3Invariance.coefficient, map_ofNat]
end CompactLaurentBridge
