module
public import modern.N2BaseDiagnostic
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "ROW3 imports loaded"
  out.flush)
set_option profiler true
namespace PrimeCyclicity.N2Modern
variable {k D : Type*} [CommRing k] [DivisionRing D] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
def processed3 : List Term := (((Int.ofNat 9), (Int.negSucc 0)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))) :: N2.processed2
def acc3 : List Term := [
  (((Int.negSucc 0), (Int.negSucc 9)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.negSucc 6)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.negSucc 10)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.negSucc 7)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 0), (Int.negSucc 4)), ((Int.negSucc 3), (Int.negSucc 3), (Int.negSucc 3), (Int.negSucc 3))),
  (((Int.ofNat 1), (Int.negSucc 8)), ((Int.negSucc 1), (Int.negSucc 2), (Int.negSucc 1), (Int.negSucc 0))),
  (((Int.ofNat 1), (Int.negSucc 5)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 1), (Int.negSucc 2)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 9)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 6)), ((Int.negSucc 0), (Int.negSucc 1), (Int.ofNat 0), (Int.negSucc 2))),
  (((Int.ofNat 2), (Int.negSucc 3)), ((Int.ofNat 4), (Int.ofNat 2), (Int.ofNat 3), (Int.negSucc 0))),
  (((Int.ofNat 2), (Int.negSucc 0)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 3), (Int.negSucc 7)), ((Int.ofNat 0), (Int.negSucc 1), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 3), (Int.negSucc 4)), ((Int.ofNat 2), (Int.negSucc 0), (Int.ofNat 2), (Int.ofNat 0))),
  (((Int.ofNat 3), (Int.negSucc 1)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 3), (Int.ofNat 2))),
  (((Int.ofNat 3), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 3), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.negSucc 8)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 4), (Int.negSucc 5)), ((Int.negSucc 1), (Int.negSucc 0), (Int.negSucc 2), (Int.negSucc 2))),
  (((Int.ofNat 4), (Int.negSucc 2)), ((Int.ofNat 2), (Int.ofNat 4), (Int.ofNat 2), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.ofNat 0)), ((Int.ofNat 2), (Int.ofNat 4), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 4), (Int.ofNat 3)), ((Int.ofNat 0), (Int.negSucc 3), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.negSucc 6)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.negSucc 3)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 4), (Int.ofNat 3))),
  (((Int.ofNat 5), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 1), (Int.ofNat 1))),
  (((Int.ofNat 5), (Int.ofNat 2)), ((Int.negSucc 1), (Int.negSucc 3), (Int.negSucc 2), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.ofNat 5)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 6), (Int.negSucc 7)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 6), (Int.negSucc 4)), ((Int.ofNat 1), (Int.negSucc 0), (Int.negSucc 1), (Int.ofNat 1))),
  (((Int.ofNat 6), (Int.negSucc 1)), ((Int.negSucc 4), (Int.negSucc 4), (Int.negSucc 3), (Int.negSucc 1))),
  (((Int.ofNat 6), (Int.ofNat 1)), ((Int.ofNat 4), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 6), (Int.ofNat 4)), ((Int.negSucc 2), (Int.negSucc 4), (Int.negSucc 3), (Int.negSucc 3))),
  (((Int.ofNat 6), (Int.ofNat 7)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 7), (Int.negSucc 5)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 3), (Int.ofNat 2))),
  (((Int.ofNat 7), (Int.negSucc 2)), ((Int.negSucc 0), (Int.ofNat 1), (Int.negSucc 0), (Int.ofNat 3))),
  (((Int.ofNat 7), (Int.ofNat 0)), ((Int.negSucc 3), (Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 7), (Int.ofNat 3)), ((Int.ofNat 2), (Int.ofNat 4), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 7), (Int.ofNat 6)), ((Int.negSucc 1), (Int.ofNat 2), (Int.ofNat 3), (Int.ofNat 2))),
  (((Int.ofNat 7), (Int.ofNat 9)), ((Int.negSucc 3), (Int.negSucc 3), (Int.negSucc 3), (Int.negSucc 3))),
  (((Int.ofNat 8), (Int.negSucc 6)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 8), (Int.negSucc 3)), ((Int.ofNat 1), (Int.ofNat 3), (Int.negSucc 1), (Int.ofNat 0))),
  (((Int.ofNat 8), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.ofNat 8), (Int.ofNat 2)), ((Int.ofNat 0), (Int.ofNat 1), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 8), (Int.ofNat 5)), ((Int.negSucc 3), (Int.negSucc 3), (Int.negSucc 3), (Int.negSucc 2))),
  (((Int.ofNat 8), (Int.ofNat 8)), ((Int.negSucc 3), (Int.negSucc 3), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.ofNat 8), (Int.ofNat 11)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 9), (Int.negSucc 4)), ((Int.ofNat 1), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 9), (Int.negSucc 1)), ((Int.ofNat 2), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 9), (Int.ofNat 1)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 9), (Int.ofNat 4)), ((Int.ofNat 4), (Int.ofNat 5), (Int.ofNat 6), (Int.ofNat 6))),
  (((Int.ofNat 9), (Int.ofNat 7)), ((Int.negSucc 0), (Int.ofNat 1), (Int.ofNat 2), (Int.ofNat 3))),
  (((Int.ofNat 9), (Int.ofNat 10)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 10), (Int.negSucc 5)), ((Int.ofNat 0), (Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 10), (Int.negSucc 2)), ((Int.ofNat 1), (Int.ofNat 1), (Int.negSucc 0), (Int.negSucc 3))),
  (((Int.ofNat 10), (Int.ofNat 0)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 10), (Int.ofNat 3)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 3), (Int.ofNat 3))),
  (((Int.ofNat 10), (Int.ofNat 6)), ((Int.ofNat 0), (Int.negSucc 2), (Int.negSucc 4), (Int.negSucc 2))),
  (((Int.ofNat 10), (Int.ofNat 9)), ((Int.ofNat 3), (Int.ofNat 2), (Int.ofNat 4), (Int.ofNat 1))),
  (((Int.ofNat 10), (Int.ofNat 12)), ((Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.ofNat 11), (Int.negSucc 3)), ((Int.ofNat 1), (Int.ofNat 3), (Int.ofNat 4), (Int.ofNat 2))),
  (((Int.ofNat 11), (Int.negSucc 0)), ((Int.ofNat 3), (Int.ofNat 4), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 11), (Int.ofNat 2)), ((Int.negSucc 4), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 11), (Int.ofNat 5)), ((Int.ofNat 4), (Int.ofNat 5), (Int.ofNat 4), (Int.ofNat 1))),
  (((Int.ofNat 11), (Int.ofNat 8)), ((Int.ofNat 4), (Int.ofNat 4), (Int.negSucc 0), (Int.ofNat 1))),
  (((Int.ofNat 11), (Int.ofNat 11)), ((Int.negSucc 2), (Int.negSucc 3), (Int.negSucc 3), (Int.negSucc 3))),
  (((Int.ofNat 12), (Int.negSucc 4)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 12), (Int.negSucc 1)), ((Int.negSucc 0), (Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 3))),
  (((Int.ofNat 12), (Int.ofNat 1)), ((Int.negSucc 1), (Int.negSucc 3), (Int.negSucc 5), (Int.negSucc 0))),
  (((Int.ofNat 12), (Int.ofNat 4)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 1))),
  (((Int.ofNat 12), (Int.ofNat 7)), ((Int.ofNat 2), (Int.negSucc 1), (Int.negSucc 0), (Int.negSucc 2))),
  (((Int.ofNat 12), (Int.ofNat 10)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 13), (Int.negSucc 2)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 13), (Int.ofNat 0)), ((Int.ofNat 2), (Int.ofNat 5), (Int.ofNat 2), (Int.ofNat 3))),
  (((Int.ofNat 13), (Int.ofNat 3)), ((Int.ofNat 1), (Int.ofNat 1), (Int.negSucc 3), (Int.negSucc 1))),
  (((Int.ofNat 13), (Int.ofNat 6)), ((Int.ofNat 1), (Int.ofNat 2), (Int.ofNat 4), (Int.ofNat 3))),
  (((Int.ofNat 13), (Int.ofNat 9)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 1), (Int.ofNat 1))),
  (((Int.ofNat 14), (Int.negSucc 3)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 14), (Int.negSucc 0)), ((Int.negSucc 1), (Int.negSucc 3), (Int.negSucc 2), (Int.negSucc 2))),
  (((Int.ofNat 14), (Int.ofNat 2)), ((Int.negSucc 0), (Int.negSucc 4), (Int.negSucc 3), (Int.negSucc 2))),
  (((Int.ofNat 14), (Int.ofNat 5)), ((Int.negSucc 2), (Int.negSucc 4), (Int.negSucc 3), (Int.negSucc 3))),
  (((Int.ofNat 14), (Int.ofNat 8)), ((Int.negSucc 3), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 15), (Int.negSucc 1)), ((Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 2), (Int.negSucc 2))),
  (((Int.ofNat 15), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 3), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.ofNat 15), (Int.ofNat 4)), ((Int.negSucc 2), (Int.negSucc 0), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.ofNat 15), (Int.ofNat 7)), ((Int.ofNat 2), (Int.ofNat 4), (Int.ofNat 4), (Int.ofNat 4))),
  (((Int.ofNat 16), (Int.negSucc 2)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 16), (Int.ofNat 0)), ((Int.negSucc 4), (Int.negSucc 3), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.ofNat 16), (Int.ofNat 3)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 5), (Int.ofNat 1))),
  (((Int.ofNat 16), (Int.ofNat 6)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 17), (Int.negSucc 0)), ((Int.ofNat 1), (Int.ofNat 3), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.ofNat 17), (Int.ofNat 2)), ((Int.negSucc 0), (Int.ofNat 1), (Int.ofNat 2), (Int.ofNat 0))),
  (((Int.ofNat 17), (Int.ofNat 5)), ((Int.ofNat 2), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 18), (Int.negSucc 1)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 18), (Int.ofNat 1)), ((Int.negSucc 1), (Int.negSucc 2), (Int.negSucc 1), (Int.negSucc 2))),
  (((Int.ofNat 18), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 4), (Int.ofNat 1))),
  (((Int.ofNat 19), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 19), (Int.ofNat 3)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 20), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "ROW3 before kernel certificate"
  out.flush)
theorem row3_certificate : rowStep (((Int.ofNat 9), (Int.negSucc 0)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))) numerator N2.acc2 = acc3 := by
  decide +kernel
#print axioms row3_certificate
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "ROW3 after kernel certificate; before semantics"
  out.flush)
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_acc3 : evalLaurent q U V acc3 =
    evalLaurent q U V processed3 * evalLaurent q U V numerator := by
  rw [← row3_certificate, evalLaurent_rowStep q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV, N2.eval_acc2 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
  change _ = (evalTerm q U V (((Int.ofNat 9), (Int.negSucc 0)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))) + evalLaurent q U V N2.processed2) * _
  exact (add_mul _ _ _).symm
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "ROW3 semantic theorem complete"
  out.flush)
#print axioms eval_acc3
end PrimeCyclicity.N2Modern
