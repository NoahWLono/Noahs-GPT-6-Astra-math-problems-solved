module
public import modern.N4Row59_2NC
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
set_option profiler true
set_option linter.all false
namespace PrimeCyclicity.N4Modern
variable {k D : Type*} [CommRing k] [DivisionRing D] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
noncomputable def acc59_3 : List Term := N4Split59.acc3
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N4 row59 chunk3: arithmetic starts"
  out.flush)
theorem row59_chunk3_certificate : rowStep selected59 chunk3 acc59_2 = acc59_3 := by
  exact N4Split59.chunk3_certificate
#print axioms row59_chunk3_certificate
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_step59_3 : evalLaurent q U V acc59_3 =
    evalTerm q U V selected59 * evalLaurent q U V chunk3 + evalLaurent q U V acc59_2 := by
  rw [← row59_chunk3_certificate, evalLaurent_rowStep q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
#print axioms eval_step59_3
noncomputable def acc59 : List Term := acc59_3
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_acc59 : evalLaurent q U V acc59 =
    evalLaurent q U V processed59 * (evalLaurent q U V numerator)^3 := by
  change evalLaurent q U V acc59_3 = _
  rw [eval_step59_3 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV, eval_step59_2 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV, eval_step59_1 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV, eval_acc58 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
  change _ = (evalTerm q U V selected59 + evalLaurent q U V processed58) * _
  rw [add_mul, N3Modern.numerator_cubed q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV, input_split]
  simp only [evalLaurent_append, mul_add]
  ac_rfl
#print axioms eval_acc59
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N4 row59 chunk3: semantic complete"
  out.flush)
end PrimeCyclicity.N4Modern
