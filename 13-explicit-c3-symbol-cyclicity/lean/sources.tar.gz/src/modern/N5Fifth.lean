module
public import modern.N5Row69_6
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N5 N5Row69_6: imports loaded"
  out.flush)
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
set_option profiler true
set_option linter.all false
namespace PrimeCyclicity.N5Modern
variable {k D : Type*} [CommRing k] [DivisionRing D] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
theorem processed69_eq_numerator : processed69 = numerator := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem numerator_fifth : (evalLaurent q U V numerator)^5 = evalLaurent q U V acc69 := by
  rw [eval_acc69 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV, processed69_eq_numerator]
  exact pow_succ' _ 4
#print axioms numerator_fifth
#check @numerator_fifth
end PrimeCyclicity.N5Modern
