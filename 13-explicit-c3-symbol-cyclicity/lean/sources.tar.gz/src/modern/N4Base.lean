module
public import modern.N4Split59_3
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
set_option profiler true
set_option linter.all false
namespace PrimeCyclicity.N4Modern
variable {k D : Type*} [CommRing k] [DivisionRing D] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
def chunk1 := N4Split59.chunk1
def chunk2 := N4Split59.chunk2
def chunk3 := N4Split59.chunk3
def processed0 : List Term := []
def acc0 : List Term := []
theorem input_split : N3Modern.acc69 = chunk1 ++ chunk2 ++ chunk3 := N4Split59.input_split
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_acc0 : evalLaurent q U V acc0 = evalLaurent q U V processed0 * (evalLaurent q U V numerator)^3 := by
  change 0 = 0 * _
  exact (zero_mul _).symm
end PrimeCyclicity.N4Modern
