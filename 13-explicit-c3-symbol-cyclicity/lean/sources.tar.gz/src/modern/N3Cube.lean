module
public import modern.N3Row69
@[expose] public section
namespace PrimeCyclicity.N3Modern
variable {k D : Type*} [CommRing k] [DivisionRing D] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)

theorem processed69_eq_numerator : processed69 = numerator := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem numerator_cubed : (evalLaurent q U V numerator)^3 = evalLaurent q U V acc69 := by
  rw [eval_acc69 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV, processed69_eq_numerator]
  exact pow_succ' _ 2
#print axioms numerator_cubed
#check @numerator_cubed
end PrimeCyclicity.N3Modern
