module
public import modern.N4Row69_3NC
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
set_option profiler true
set_option linter.all false
namespace PrimeCyclicity.N4Modern
variable {k D : Type*} [CommRing k] [DivisionRing D] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
theorem processed69_eq_numerator : processed69 = numerator := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem numerator_fourth : (evalLaurent q U V numerator)^4 = evalLaurent q U V acc69 := by
  rw [eval_acc69 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV, processed69_eq_numerator]
  exact pow_succ' _ 3
#print axioms numerator_fourth
#check @numerator_fourth
end PrimeCyclicity.N4Modern
