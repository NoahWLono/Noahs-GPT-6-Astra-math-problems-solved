module
public import modern.N3PilotFirst
public import modern.N3PilotInterior
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
set_option profiler true
namespace PrimeCyclicity.N3Modern
variable {k D : Type*} [CommRing k] [DivisionRing D] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N3 chain row1: loaded"
  out.flush)
def processed0 : List Term := []
def acc0 : List Term := []
def processed1 : List Term := (((Int.ofNat 10), (Int.ofNat 1)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))) :: processed0
def acc1 : List Term := N3PilotFirst.after
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N3 chain row1: arithmetic starts"
  out.flush)
theorem row1_certificate : rowStep (((Int.ofNat 10), (Int.ofNat 1)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))) N2Modern.acc69 acc0 = acc1 := by
  exact N3PilotFirst.row_certificate
#print axioms row1_certificate
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_acc1 : evalLaurent q U V acc1 =
    evalLaurent q U V processed1 * (evalLaurent q U V numerator)^2 := by
  rw [← row1_certificate, evalLaurent_rowStep q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV, ← N2Modern.numerator_squared q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
  change _ + 0 = (_ + 0) * _
  simp only [add_zero]
#print axioms eval_acc1
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N3 chain row1: semantic complete"
  out.flush)
end PrimeCyclicity.N3Modern
