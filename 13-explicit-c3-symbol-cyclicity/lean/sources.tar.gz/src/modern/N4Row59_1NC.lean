module
public import modern.N4Row58_3NC
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
set_option profiler true
set_option linter.all false
namespace PrimeCyclicity.N4Modern
variable {k D : Type*} [CommRing k] [DivisionRing D] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
noncomputable def selected59 : Term := (((Int.negSucc 5), (Int.negSucc 0)), ((Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1)))
noncomputable def processed59 : List Term := selected59 :: processed58
noncomputable def acc59_1 : List Term := N4Split59.acc1
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N4 row59 chunk1: arithmetic starts"
  out.flush)
theorem row59_chunk1_certificate : rowStep selected59 chunk1 acc58 = acc59_1 := by
  exact N4Split59.chunk1_certificate
#print axioms row59_chunk1_certificate
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_step59_1 : evalLaurent q U V acc59_1 =
    evalTerm q U V selected59 * evalLaurent q U V chunk1 + evalLaurent q U V acc58 := by
  rw [← row59_chunk1_certificate, evalLaurent_rowStep q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
#print axioms eval_step59_1
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N4 row59 chunk1: semantic complete"
  out.flush)
end PrimeCyclicity.N4Modern
