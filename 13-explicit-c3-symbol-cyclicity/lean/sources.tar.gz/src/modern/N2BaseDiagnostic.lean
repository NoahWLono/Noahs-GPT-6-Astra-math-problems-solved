module
public import modern.FuelGate
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "BASE imports loaded"
  out.flush)
set_option profiler true
namespace PrimeCyclicity.N2
variable {k D : Type*} [CommRing k] [DivisionRing D] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
def processed1 : List Term := [(((Int.ofNat 10), (Int.ofNat 1)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))]
def processed2 : List Term := (((Int.ofNat 9), (Int.ofNat 2)), ((Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))) :: processed1
def acc1 : List Term := PrimeCyclicity.row1
def acc2 : List Term := PrimeCyclicity.row2
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "BASE before eval_acc1"
  out.flush)
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_acc1 : evalLaurent q U V acc1 =
    evalLaurent q U V processed1 * evalLaurent q U V numerator := by
  change evalLaurent q U V PrimeCyclicity.row1 = _
  rw [← row1_certificate, evalLaurent_rowStep q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
  change evalTerm q U V (((Int.ofNat 10), (Int.ofNat 1)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))) * evalLaurent q U V numerator + 0 =
    (evalTerm q U V (((Int.ofNat 10), (Int.ofNat 1)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))) + 0) * evalLaurent q U V numerator
  simp only [add_zero]
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "BASE after eval_acc1; before eval_acc2"
  out.flush)
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_acc2 : evalLaurent q U V acc2 =
    evalLaurent q U V processed2 * evalLaurent q U V numerator := by
  change evalLaurent q U V PrimeCyclicity.row2 = _
  rw [← row2_certificate, evalLaurent_rowStep q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
  change evalTerm q U V (((Int.ofNat 9), (Int.ofNat 2)), ((Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))) * evalLaurent q U V numerator +
    evalLaurent q U V acc1 = _
  rw [eval_acc1 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
  change _ = (evalTerm q U V (((Int.ofNat 9), (Int.ofNat 2)), ((Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))) + evalLaurent q U V processed1) * _
  exact (add_mul _ _ _).symm
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "BASE after eval_acc2"
  out.flush)
#print axioms eval_acc1
#print axioms eval_acc2
end PrimeCyclicity.N2
