module
public import modern.N4Row59_1NC
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
set_option profiler true
set_option linter.all false
namespace PrimeCyclicity.N4Modern
variable {k D : Type*} [CommRing k] [DivisionRing D] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
noncomputable def acc59_2 : List Term := N4Split59.acc2
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N4 row59 chunk2: arithmetic starts"
  out.flush)
theorem row59_chunk2_certificate : rowStep selected59 chunk2 acc59_1 = acc59_2 := by
  exact N4Split59.chunk2_certificate
#print axioms row59_chunk2_certificate
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_step59_2 : evalLaurent q U V acc59_2 =
    evalTerm q U V selected59 * evalLaurent q U V chunk2 + evalLaurent q U V acc59_1 := by
  rw [← row59_chunk2_certificate, evalLaurent_rowStep q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
#print axioms eval_step59_2
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N4 row59 chunk2: semantic complete"
  out.flush)
end PrimeCyclicity.N4Modern
