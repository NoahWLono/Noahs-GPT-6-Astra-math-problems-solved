module
public import modern.N2Rows21
@[expose] public section
namespace PrimeCyclicity.N2Modern
variable {k D : Type*} [CommRing k] [DivisionRing D] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)

theorem processed69_eq_numerator : processed69 = numerator := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem numerator_squared : (evalLaurent q U V numerator)^2 = evalLaurent q U V acc69 := by
  rw [eval_acc69 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV, processed69_eq_numerator, pow_two]
#print axioms numerator_squared
#check @numerator_squared
end PrimeCyclicity.N2Modern
