module
public import Mathlib.Algebra.Algebra.Basic
public import Mathlib.Algebra.Group.Commute.Basic
public import Mathlib.Algebra.Group.Commute.Units
public import Mathlib.Algebra.GroupWithZero.Semiconj
import Mathlib.Tactic.Ring

@[expose] public section
namespace PrimeCyclicity

variable {D : Type*} [DivisionRing D]

/-- Integer normal ordering starts from the actual quantum relation. -/
theorem left_zpow (Q U V : Dˣ) (hUV : U * V = Q * V * U)
    (hQV : Commute Q V) (j : ℤ) :
    U * V ^ j = Q ^ j * V ^ j * U := by
  have h : SemiconjBy U V (Q * V) := hUV
  have hj := h.zpow_right j
  change U * V ^ j = (Q * V) ^ j * U at hj
  rw [hQV.mul_zpow] at hj
  exact hj

/-- Full integer normal ordering, derived rather than assumed. -/
theorem normal_order (Q U V : Dˣ) (hUV : U * V = Q * V * U)
    (hQU : Commute Q U) (hQV : Commute Q V) (i j : ℤ) :
    V ^ j * U ^ i = Q ^ (-j * i) * U ^ i * V ^ j := by
  have hj := left_zpow Q U V hUV hQV j
  have h : SemiconjBy (V ^ j) U (Q ^ (-j) * U) := by
    change V ^ j * U = (Q ^ (-j) * U) * V ^ j
    calc
      V ^ j * U = (Q ^ j)⁻¹ * (Q ^ j * (V ^ j * U)) := by simp
      _ = (Q ^ j)⁻¹ * (U * V ^ j) := by
        rw [show Q ^ j * (V ^ j * U) = U * V ^ j by
          simpa only [mul_assoc] using hj.symm]
      _ = (Q ^ (-j) * U) * V ^ j := by rw [zpow_neg, mul_assoc]
  have hi := h.zpow_right i
  change V ^ j * U ^ i = (Q ^ (-j) * U) ^ i * V ^ j at hi
  rw [(hQU.zpow_left (-j)).mul_zpow, ← zpow_mul] at hi
  exact hi

theorem monomial_mul (Q U V : Dˣ) (hUV : U * V = Q * V * U)
    (hQU : Commute Q U) (hQV : Commute Q V) (i j k l : ℤ) :
    (U^i * V^j) * (U^k * V^l) = Q^(-j*k) * (U^(i+k) * V^(j+l)) := by
  calc
    (U^i * V^j) * (U^k * V^l) = U^i * (V^j * U^k) * V^l := by
      simp only [mul_assoc]
    _ = U^i * (Q^(-j*k) * U^k * V^j) * V^l := by
      rw [normal_order Q U V hUV hQU hQV k j]
    _ = Q^(-j*k) * ((U^i * U^k) * (V^j * V^l)) := by
      simp only [← mul_assoc]
      rw [(hQU.zpow_zpow (-j*k) i).symm.eq]
    _ = Q^(-j*k) * (U^(i+k) * V^(j+l)) := by rw [zpow_add, zpow_add]

abbrev Coeff := ℤ × ℤ × ℤ × ℤ
abbrev Term := (ℤ × ℤ) × Coeff

def evalCoeff {k : Type*} [CommRing k] (q : k) (a : Coeff) : k :=
  a.1 + a.2.1 * q + a.2.2.1 * q ^ 2 + a.2.2.2 * q ^ 3

def addCoeff (a b : Coeff) : Coeff :=
  (a.1 + b.1, a.2.1 + b.2.1, a.2.2.1 + b.2.2.1, a.2.2.2 + b.2.2.2)

def mulCoeff (a b : Coeff) : Coeff :=
  let r₀ := a.1*b.1
  let r₁ := a.1*b.2.1 + a.2.1*b.1
  let r₂ := a.1*b.2.2.1 + a.2.1*b.2.1 + a.2.2.1*b.1
  let r₃ := a.1*b.2.2.2 + a.2.1*b.2.2.1 + a.2.2.1*b.2.1 + a.2.2.2*b.1
  let r₄ := a.2.1*b.2.2.2 + a.2.2.1*b.2.2.1 + a.2.2.2*b.2.1
  let r₅ := a.2.2.1*b.2.2.2 + a.2.2.2*b.2.2.1
  let r₆ := a.2.2.2*b.2.2.2
  (r₀-r₄+r₅, r₁-r₄+r₆, r₂-r₄, r₃-r₄)

def shiftCoeff : ℕ → Coeff → Coeff
  | 0, a => a
  | n+1, a => shiftCoeff n (-a.2.2.2, a.1-a.2.2.2, a.2.1-a.2.2.2, a.2.2.1-a.2.2.2)

theorem evalCoeff_add {k : Type*} [CommRing k] (q : k) (a b : Coeff) :
    evalCoeff q (addCoeff a b) = evalCoeff q a + evalCoeff q b := by
  simp [evalCoeff, addCoeff]
  ring

theorem evalCoeff_mul {k : Type*} [CommRing k] (q : k)
    (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5 = 1) (a b : Coeff) :
    evalCoeff q (mulCoeff a b) = evalCoeff q a * evalCoeff q b := by
  have h₆ : q^6 = q := by rw [show (6:ℕ)=5+1 by rfl, pow_succ, h₅, one_mul]
  simp only [evalCoeff, mulCoeff, Int.cast_add, Int.cast_sub, Int.cast_mul]
  ring_nf
  rw [h₆, h₅, h₄]
  ring

theorem evalCoeff_shift {k : Type*} [CommRing k] (q : k)
    (h₄ : q^4 = -(1+q+q^2+q^3)) (n : ℕ) (a : Coeff) :
    evalCoeff q (shiftCoeff n a) = q^n * evalCoeff q a := by
  induction n generalizing a with
  | zero => simp [shiftCoeff]
  | succ n ih =>
    rw [shiftCoeff, ih]
    have h : evalCoeff q (-a.2.2.2, a.1-a.2.2.2, a.2.1-a.2.2.2,
        a.2.2.1-a.2.2.2) = q * evalCoeff q a := by
      simp only [evalCoeff, Int.cast_sub, Int.cast_neg]
      ring_nf
      rw [h₄]
      ring
    rw [h, pow_succ, mul_assoc]

def evalTerm {k : Type*} [CommRing k] [Algebra k D]
    (q : k) (U V : Dˣ) (t : Term) : D :=
  algebraMap k D (evalCoeff q t.2) * (U ^ t.1.1 : Dˣ) * (V ^ t.1.2 : Dˣ)

def insertTerm (t : Term) : List Term → List Term
  | [] => [t]
  | s :: p => if t.1 = s.1 then (t.1, addCoeff t.2 s.2) :: p
      else s :: insertTerm t p

def mulTerm (t s : Term) : Term :=
  ((t.1.1+s.1.1, t.1.2+s.1.2),
    shiftCoeff ((-t.1.2*s.1.1)%5).toNat (mulCoeff t.2 s.2))

def addLaurent : List Term → List Term → List Term
  | [], p => p
  | t :: p, r => insertTerm t (addLaurent p r)

def mulBy (t : Term) : List Term → List Term
  | [] => []
  | s :: p => insertTerm (mulTerm t s) (mulBy t p)

def mulLaurent : List Term → List Term → List Term
  | [], _ => []
  | t :: p, r => addLaurent (mulBy t r) (mulLaurent p r)

theorem phase_eval {k : Type*} [CommRing k] [Algebra k D]
    (q : k) (Q : Dˣ) (hQ : (Q : D) = algebraMap k D q) (h₅ : Q^5=1) (m : ℤ) :
    ((Q^m : Dˣ) : D) = algebraMap k D (q^((m%5).toNat)) := by
  have hz : Q^m = Q^((m%5).toNat) := by
    calc
      Q^m = Q^(m%5) := zpow_eq_zpow_emod' m h₅
      _ = Q^(((m%5).toNat : ℕ):ℤ) := congrArg (fun z : ℤ => Q^z)
        (Int.toNat_of_nonneg (Int.emod_nonneg m (by decide : (5:ℤ) ≠ 0))).symm
      _ = Q^((m%5).toNat) := by rw [zpow_natCast]
  rw [hz]
  simp [hQ]

theorem scalar_monomial_mul {k : Type*} [CommRing k] [Algebra k D]
    (a b : k) (X Y : Dˣ) :
    (algebraMap k D a * (X:D)) * (algebraMap k D b * (Y:D)) =
      algebraMap k D (a*b) * ((X*Y : Dˣ):D) := by
  rw [map_mul, Units.val_mul]
  calc
    (algebraMap k D a * (X:D)) * (algebraMap k D b * (Y:D)) =
        algebraMap k D a * ((X:D) * algebraMap k D b) * (Y:D) := by
      simp only [mul_assoc]
    _ = algebraMap k D a * (algebraMap k D b * (X:D)) * (Y:D) := by
      rw [(Algebra.commutes b (X:D)).symm]
    _ = (algebraMap k D a * algebraMap k D b) * ((X:D) * (Y:D)) := by
      simp only [mul_assoc]

theorem evalTerm_eq {k : Type*} [CommRing k] [Algebra k D]
    (q : k) (U V : Dˣ) (t : Term) :
    evalTerm q U V t = algebraMap k D (evalCoeff q t.2) *
      ((U^t.1.1 * V^t.1.2 : Dˣ):D) := by
  simp [evalTerm, mul_assoc]

theorem evalTerm_mul {k : Type*} [CommRing k] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V) (t s : Term) :
    evalTerm q U V (mulTerm t s) = evalTerm q U V t * evalTerm q U V s := by
  simp only [evalTerm_eq]
  rw [scalar_monomial_mul, monomial_mul Q U V hUV hQU hQV]
  simp only [mulTerm, evalCoeff_shift q h₄, evalCoeff_mul q h₄ h₅, Units.val_mul]
  rw [phase_eval q Q hQ hQ₅,
    mul_comm (q^((-t.1.2*s.1.1)%5).toNat) (evalCoeff q t.2 * evalCoeff q s.2)]
  simp only [map_mul, mul_assoc]

def evalLaurent {k : Type*} [CommRing k] [Algebra k D]
    (q : k) (U V : Dˣ) (p : List Term) : D :=
  (p.map (evalTerm q U V)).sum

theorem evalLaurent_append {k : Type*} [CommRing k] [Algebra k D]
    (q : k) (U V : Dˣ) (p r : List Term) :
    evalLaurent q U V (p ++ r) = evalLaurent q U V p + evalLaurent q U V r := by
  simp [evalLaurent]

theorem evalLaurent_insert {k : Type*} [CommRing k] [Algebra k D]
    (q : k) (U V : Dˣ) (t : Term) (p : List Term) :
    evalLaurent q U V (insertTerm t p) = evalTerm q U V t + evalLaurent q U V p := by
  induction p with
  | nil => simp [insertTerm, evalLaurent]
  | cons s p ih =>
    simp only [insertTerm]
    split_ifs with h
    · simp only [evalLaurent, List.map_cons, List.sum_cons]
      have he : evalTerm q U V (t.1, addCoeff t.2 s.2) =
          evalTerm q U V t + evalTerm q U V s := by
        simp only [evalTerm, evalCoeff_add, map_add, add_mul]
        rw [h]
      rw [he, add_assoc]
    · change evalTerm q U V s + evalLaurent q U V (insertTerm t p) =
          evalTerm q U V t + (evalTerm q U V s + evalLaurent q U V p)
      rw [ih, add_left_comm]

theorem evalLaurent_add {k : Type*} [CommRing k] [Algebra k D]
    (q : k) (U V : Dˣ) (p r : List Term) :
    evalLaurent q U V (addLaurent p r) = evalLaurent q U V p + evalLaurent q U V r := by
  induction p with
  | nil => simp [addLaurent, evalLaurent]
  | cons t p ih =>
    rw [addLaurent, evalLaurent_insert, ih]
    simp [evalLaurent, add_assoc]

theorem evalLaurent_mulBy {k : Type*} [CommRing k] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
    (t : Term) (p : List Term) :
    evalLaurent q U V (mulBy t p) = evalTerm q U V t * evalLaurent q U V p := by
  induction p with
  | nil => simp [mulBy, evalLaurent]
  | cons s p ih =>
    rw [mulBy, evalLaurent_insert, evalTerm_mul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV, ih]
    simp [evalLaurent, mul_add]

theorem evalLaurent_mul {k : Type*} [CommRing k] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
    (p r : List Term) :
    evalLaurent q U V (mulLaurent p r) = evalLaurent q U V p * evalLaurent q U V r := by
  induction p with
  | nil => simp [mulLaurent, evalLaurent]
  | cons t p ih =>
    rw [mulLaurent, evalLaurent_add,
      evalLaurent_mulBy q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV, ih]
    simp [evalLaurent, add_mul]

def mergeLaurent : List Term → List Term → List Term
  | [], r => r
  | p, [] => p
  | t::p, s::r =>
    if t.1 = s.1 then (t.1, addCoeff t.2 s.2) :: mergeLaurent p r
    else if t.1.1 < s.1.1 ∨ (t.1.1 = s.1.1 ∧ t.1.2 < s.1.2) then
      t :: mergeLaurent p (s::r)
    else s :: mergeLaurent (t::p) r
termination_by p r => p.length + r.length

def trimLaurent (p : List Term) : List Term := p.filter (fun t => t.2 != (0,0,0,0))

def fastMul : List Term → List Term → List Term
  | [], _ => []
  | t::p, r => trimLaurent (mergeLaurent (r.map (mulTerm t)) (fastMul p r))

theorem evalLaurent_merge {k : Type*} [CommRing k] [Algebra k D]
    (q : k) (U V : Dˣ) (p r : List Term) :
    evalLaurent q U V (mergeLaurent p r) = evalLaurent q U V p + evalLaurent q U V r := by
  induction p generalizing r with
  | nil => simp [mergeLaurent, evalLaurent]
  | cons t p ih =>
    induction r with
    | nil => simp [mergeLaurent, evalLaurent]
    | cons s r ihr =>
      rw [mergeLaurent]
      split_ifs with h hlt
      · have he : evalTerm q U V (t.1, addCoeff t.2 s.2) =
            evalTerm q U V t + evalTerm q U V s := by
          simp only [evalTerm, evalCoeff_add, map_add, add_mul]
          rw [h]
        change evalTerm q U V (t.1, addCoeff t.2 s.2) +
            evalLaurent q U V (mergeLaurent p r) = _
        rw [he, ih]
        simp only [evalLaurent, List.map_cons, List.sum_cons]
        ac_rfl
      · change evalTerm q U V t + evalLaurent q U V (mergeLaurent p (s::r)) = _
        rw [ih]
        simp [evalLaurent, add_assoc]
      · change evalTerm q U V s + evalLaurent q U V (mergeLaurent (t::p) r) = _
        rw [ihr]
        simp only [evalLaurent, List.map_cons, List.sum_cons]
        ac_rfl

theorem evalLaurent_trim {k : Type*} [CommRing k] [Algebra k D]
    (q : k) (U V : Dˣ) (p : List Term) :
    evalLaurent q U V (trimLaurent p) = evalLaurent q U V p := by
  induction p with
  | nil => rfl
  | cons t p ih =>
    by_cases h : t.2 = (0,0,0,0)
    · have ht : evalTerm q U V t = 0 := by simp [evalTerm, h, evalCoeff]
      simpa [trimLaurent, h, evalLaurent, ht] using ih
    · simpa [trimLaurent, h, evalLaurent] using congrArg (evalTerm q U V t + ·) ih

theorem evalLaurent_fastMul {k : Type*} [CommRing k] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
    (p r : List Term) :
    evalLaurent q U V (fastMul p r) = evalLaurent q U V p * evalLaurent q U V r := by
  have hm (t : Term) : evalLaurent q U V (r.map (mulTerm t)) =
      evalTerm q U V t * evalLaurent q U V r := by
    induction r with
    | nil => simp [evalLaurent]
    | cons s r ih =>
      simp only [List.map_cons, evalLaurent, List.sum_cons]
      rw [evalTerm_mul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
      change _ + evalLaurent q U V (r.map (mulTerm t)) = _
      rw [ih]
      simp [evalLaurent, mul_add]
  induction p with
  | nil => simp [fastMul, evalLaurent]
  | cons t p ih =>
    rw [fastMul, evalLaurent_trim, evalLaurent_merge, hm, ih]
    simp [evalLaurent, add_mul]

#print axioms left_zpow
#print axioms normal_order
#print axioms evalLaurent_append
#print axioms evalCoeff_mul
#print axioms evalCoeff_shift
#print axioms monomial_mul
#print axioms evalLaurent_insert
#print axioms evalTerm_mul
#print axioms evalLaurent_mul
#print axioms evalLaurent_fastMul

end PrimeCyclicity
