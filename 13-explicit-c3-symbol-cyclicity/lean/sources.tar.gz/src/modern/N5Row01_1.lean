module
public import modern.N5Base
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N5 N5Base: imports loaded"
  out.flush)
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
set_option profiler true
set_option linter.all false
namespace PrimeCyclicity.N5Modern
variable {k D : Type*} [CommRing k] [DivisionRing D] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
noncomputable def selected1 : Term := (((Int.ofNat 10), (Int.ofNat 1)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
noncomputable def processed1 : List Term := selected1 :: processed0
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N5 row1: selected and processed ready"
  out.flush)
noncomputable def acc1_1 : List Term := [
  (((Int.negSucc 29), (Int.negSucc 34)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.negSucc 28), (Int.negSucc 35)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.negSucc 28), (Int.negSucc 32)), ((Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.negSucc 27), (Int.negSucc 36)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.negSucc 27), (Int.negSucc 33)), ((Int.ofNat 2), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.negSucc 27), (Int.negSucc 30)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 2), (Int.ofNat 0))),
  (((Int.negSucc 26), (Int.negSucc 37)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 26), (Int.negSucc 34)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 1))),
  (((Int.negSucc 26), (Int.negSucc 31)), ((Int.ofNat 3), (Int.ofNat 1), (Int.ofNat 3), (Int.ofNat 3))),
  (((Int.negSucc 26), (Int.negSucc 28)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 3))),
  (((Int.negSucc 25), (Int.negSucc 38)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 25), (Int.negSucc 35)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.negSucc 0))),
  (((Int.negSucc 25), (Int.negSucc 32)), ((Int.ofNat 1), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 3))),
  (((Int.negSucc 25), (Int.negSucc 29)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 2), (Int.ofNat 0))),
  (((Int.negSucc 25), (Int.negSucc 26)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 2), (Int.ofNat 0))),
  (((Int.negSucc 24), (Int.negSucc 36)), ((Int.ofNat 1), (Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 2))),
  (((Int.negSucc 24), (Int.negSucc 30)), ((Int.negSucc 2), (Int.negSucc 0), (Int.ofNat 3), (Int.ofNat 0))),
  (((Int.negSucc 24), (Int.negSucc 27)), ((Int.ofNat 0), (Int.negSucc 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 24), (Int.negSucc 24)), ((Int.negSucc 4), (Int.negSucc 4), (Int.negSucc 4), (Int.negSucc 4))),
  (((Int.negSucc 23), (Int.negSucc 37)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 2))),
  (((Int.negSucc 23), (Int.negSucc 34)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 1), (Int.negSucc 2))),
  (((Int.negSucc 23), (Int.negSucc 31)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 1), (Int.negSucc 1))),
  (((Int.negSucc 23), (Int.negSucc 28)), ((Int.ofNat 3), (Int.ofNat 3), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 23), (Int.negSucc 25)), ((Int.negSucc 2), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 4))),
  (((Int.negSucc 23), (Int.negSucc 22)), ((Int.ofNat 7), (Int.ofNat 7), (Int.ofNat 7), (Int.ofNat 7))),
  (((Int.negSucc 22), (Int.negSucc 35)), ((Int.ofNat 2), (Int.negSucc 0), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.negSucc 22), (Int.negSucc 32)), ((Int.ofNat 3), (Int.ofNat 4), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.negSucc 22), (Int.negSucc 29)), ((Int.negSucc 0), (Int.ofNat 2), (Int.ofNat 2), (Int.negSucc 0))),
  (((Int.negSucc 22), (Int.negSucc 26)), ((Int.ofNat 3), (Int.ofNat 3), (Int.ofNat 6), (Int.ofNat 5))),
  (((Int.negSucc 22), (Int.negSucc 23)), ((Int.negSucc 6), (Int.ofNat 5), (Int.ofNat 0), (Int.negSucc 1))),
  (((Int.negSucc 22), (Int.negSucc 20)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 9), (Int.ofNat 0))),
  (((Int.negSucc 21), (Int.negSucc 36)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 2))),
  (((Int.negSucc 21), (Int.negSucc 33)), ((Int.ofNat 3), (Int.ofNat 3), (Int.ofNat 6), (Int.ofNat 2))),
  (((Int.negSucc 21), (Int.negSucc 30)), ((Int.ofNat 2), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 2))),
  (((Int.negSucc 21), (Int.negSucc 27)), ((Int.ofNat 2), (Int.ofNat 5), (Int.ofNat 5), (Int.ofNat 2))),
  (((Int.negSucc 21), (Int.negSucc 24)), ((Int.ofNat 3), (Int.ofNat 5), (Int.ofNat 5), (Int.ofNat 7))),
  (((Int.negSucc 21), (Int.negSucc 21)), ((Int.negSucc 8), (Int.negSucc 1), (Int.negSucc 8), (Int.negSucc 8))),
  (((Int.negSucc 21), (Int.negSucc 18)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 8))),
  (((Int.negSucc 20), (Int.negSucc 34)), ((Int.ofNat 0), (Int.negSucc 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 20), (Int.negSucc 31)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 3), (Int.ofNat 3))),
  (((Int.negSucc 20), (Int.negSucc 28)), ((Int.negSucc 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 20), (Int.negSucc 25)), ((Int.ofNat 0), (Int.negSucc 4), (Int.negSucc 1), (Int.ofNat 5))),
  (((Int.negSucc 20), (Int.negSucc 22)), ((Int.negSucc 4), (Int.negSucc 6), (Int.negSucc 6), (Int.negSucc 8))),
  (((Int.negSucc 20), (Int.negSucc 19)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 9), (Int.ofNat 0))),
  (((Int.negSucc 20), (Int.negSucc 16)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 9), (Int.ofNat 0))),
  (((Int.negSucc 19), (Int.negSucc 35)), ((Int.ofNat 0), (Int.ofNat 3), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 19), (Int.negSucc 32)), ((Int.ofNat 0), (Int.ofNat 3), (Int.ofNat 3), (Int.ofNat 0))),
  (((Int.negSucc 19), (Int.negSucc 29)), ((Int.negSucc 2), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.negSucc 19), (Int.negSucc 26)), ((Int.negSucc 4), (Int.ofNat 0), (Int.ofNat 2), (Int.negSucc 6))),
  (((Int.negSucc 19), (Int.negSucc 20)), ((Int.ofNat 9), (Int.ofNat 2), (Int.negSucc 8), (Int.ofNat 0))),
  (((Int.negSucc 19), (Int.negSucc 17)), ((Int.ofNat 0), (Int.ofNat 9), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 19), (Int.negSucc 14)), ((Int.ofNat 12), (Int.ofNat 12), (Int.ofNat 12), (Int.ofNat 12))),
  (((Int.negSucc 18), (Int.negSucc 33)), ((Int.ofNat 0), (Int.negSucc 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 18), (Int.negSucc 30)), ((Int.ofNat 3), (Int.ofNat 3), (Int.ofNat 0), (Int.negSucc 1))),
  (((Int.negSucc 18), (Int.negSucc 27)), ((Int.ofNat 7), (Int.ofNat 7), (Int.ofNat 7), (Int.ofNat 0))),
  (((Int.negSucc 18), (Int.negSucc 24)), ((Int.ofNat 5), (Int.ofNat 5), (Int.ofNat 10), (Int.ofNat 12))),
  (((Int.negSucc 18), (Int.negSucc 21)), ((Int.ofNat 0), (Int.negSucc 6), (Int.negSucc 1), (Int.ofNat 7))),
  (((Int.negSucc 18), (Int.negSucc 18)), ((Int.negSucc 8), (Int.negSucc 8), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 18), (Int.negSucc 15)), ((Int.ofNat 9), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 12))),
  (((Int.negSucc 18), (Int.negSucc 12)), ((Int.negSucc 14), (Int.negSucc 14), (Int.negSucc 14), (Int.negSucc 14))),
  (((Int.negSucc 17), (Int.negSucc 34)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 2), (Int.ofNat 0))),
  (((Int.negSucc 17), (Int.negSucc 31)), ((Int.negSucc 2), (Int.negSucc 2), (Int.negSucc 5), (Int.negSucc 0))),
  (((Int.negSucc 17), (Int.negSucc 28)), ((Int.negSucc 6), (Int.ofNat 2), (Int.ofNat 0), (Int.negSucc 4))),
  (((Int.negSucc 17), (Int.negSucc 25)), ((Int.negSucc 6), (Int.ofNat 5), (Int.ofNat 5), (Int.negSucc 6))),
  (((Int.negSucc 17), (Int.negSucc 22)), ((Int.negSucc 11), (Int.negSucc 13), (Int.negSucc 6), (Int.negSucc 6))),
  (((Int.negSucc 17), (Int.negSucc 19)), ((Int.ofNat 2), (Int.negSucc 6), (Int.negSucc 6), (Int.ofNat 2))),
  (((Int.negSucc 17), (Int.negSucc 16)), ((Int.negSucc 8), (Int.negSucc 8), (Int.negSucc 17), (Int.negSucc 11))),
  (((Int.negSucc 17), (Int.negSucc 13)), ((Int.ofNat 15), (Int.negSucc 11), (Int.ofNat 0), (Int.ofNat 3))),
  (((Int.negSucc 17), (Int.negSucc 10)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 17), (Int.ofNat 0))),
  (((Int.negSucc 16), (Int.negSucc 32)), ((Int.ofNat 5), (Int.ofNat 5), (Int.ofNat 2), (Int.ofNat 5))),
  (((Int.negSucc 16), (Int.negSucc 29)), ((Int.negSucc 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 7))),
  (((Int.negSucc 16), (Int.negSucc 26)), ((Int.negSucc 11), (Int.negSucc 4), (Int.negSucc 11), (Int.ofNat 0))),
  (((Int.negSucc 16), (Int.negSucc 23)), ((Int.negSucc 11), (Int.negSucc 11), (Int.negSucc 23), (Int.negSucc 18))),
  (((Int.negSucc 16), (Int.negSucc 20)), ((Int.negSucc 6), (Int.negSucc 1), (Int.negSucc 4), (Int.negSucc 6))),
  (((Int.negSucc 16), (Int.negSucc 17)), ((Int.negSucc 2), (Int.negSucc 11), (Int.negSucc 11), (Int.negSucc 2))),
  (((Int.negSucc 16), (Int.negSucc 14)), ((Int.negSucc 8), (Int.negSucc 11), (Int.negSucc 11), (Int.negSucc 14))),
  (((Int.negSucc 16), (Int.negSucc 11)), ((Int.ofNat 18), (Int.ofNat 3), (Int.ofNat 18), (Int.ofNat 18))),
  (((Int.negSucc 16), (Int.negSucc 8)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 18))),
  (((Int.negSucc 15), (Int.negSucc 33)), ((Int.ofNat 0), (Int.ofNat 5), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 15), (Int.negSucc 30)), ((Int.ofNat 0), (Int.negSucc 1), (Int.negSucc 4), (Int.ofNat 2))),
  (((Int.negSucc 15), (Int.negSucc 27)), ((Int.negSucc 1), (Int.negSucc 6), (Int.negSucc 6), (Int.negSucc 11))),
  (((Int.negSucc 15), (Int.negSucc 24)), ((Int.ofNat 0), (Int.ofNat 12), (Int.ofNat 12), (Int.ofNat 0))),
  (((Int.negSucc 15), (Int.negSucc 21)), ((Int.negSucc 4), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 11))),
  (((Int.negSucc 15), (Int.negSucc 18)), ((Int.ofNat 2), (Int.negSucc 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 15), (Int.negSucc 15)), ((Int.ofNat 0), (Int.ofNat 12), (Int.ofNat 3), (Int.negSucc 11))),
  (((Int.negSucc 15), (Int.negSucc 12)), ((Int.ofNat 12), (Int.ofNat 15), (Int.ofNat 15), (Int.ofNat 18))),
  (((Int.negSucc 15), (Int.negSucc 9)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 17), (Int.ofNat 0))),
  (((Int.negSucc 15), (Int.negSucc 6)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 17), (Int.ofNat 0))),
  (((Int.negSucc 14), (Int.negSucc 31)), ((Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 5), (Int.negSucc 6))),
  (((Int.negSucc 14), (Int.negSucc 25)), ((Int.ofNat 12), (Int.negSucc 6), (Int.negSucc 11), (Int.ofNat 0))),
  (((Int.negSucc 14), (Int.negSucc 22)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 11), (Int.ofNat 0))),
  (((Int.negSucc 14), (Int.negSucc 19)), ((Int.ofNat 11), (Int.ofNat 6), (Int.ofNat 6), (Int.ofNat 6))),
  (((Int.negSucc 14), (Int.negSucc 16)), ((Int.ofNat 12), (Int.ofNat 0), (Int.negSucc 2), (Int.ofNat 15))),
  (((Int.negSucc 14), (Int.negSucc 10)), ((Int.negSucc 17), (Int.negSucc 2), (Int.ofNat 18), (Int.ofNat 0))),
  (((Int.negSucc 14), (Int.negSucc 7)), ((Int.ofNat 0), (Int.negSucc 17), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 14), (Int.negSucc 4)), ((Int.negSucc 18), (Int.negSucc 18), (Int.negSucc 18), (Int.negSucc 18))),
  (((Int.negSucc 13), (Int.negSucc 32)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 6))),
  (((Int.negSucc 13), (Int.negSucc 29)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 4), (Int.ofNat 9))),
  (((Int.negSucc 13), (Int.negSucc 26)), ((Int.ofNat 0), (Int.negSucc 6), (Int.negSucc 4), (Int.ofNat 7))),
  (((Int.negSucc 13), (Int.negSucc 23)), ((Int.negSucc 11), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 13), (Int.negSucc 20)), ((Int.ofNat 0), (Int.negSucc 11), (Int.ofNat 0), (Int.ofNat 6))),
  (((Int.negSucc 13), (Int.negSucc 17)), ((Int.negSucc 11), (Int.negSucc 11), (Int.negSucc 11), (Int.ofNat 3))),
  (((Int.negSucc 13), (Int.negSucc 14)), ((Int.negSucc 11), (Int.negSucc 11), (Int.negSucc 23), (Int.negSucc 26))),
  (((Int.negSucc 13), (Int.negSucc 11)), ((Int.ofNat 0), (Int.ofNat 15), (Int.ofNat 3), (Int.negSucc 14))),
  (((Int.negSucc 13), (Int.negSucc 8)), ((Int.ofNat 18), (Int.ofNat 18), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 13), (Int.negSucc 5)), ((Int.negSucc 17), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 18))),
  (((Int.negSucc 13), (Int.negSucc 2)), ((Int.ofNat 20), (Int.ofNat 20), (Int.ofNat 20), (Int.ofNat 20))),
  (((Int.negSucc 12), (Int.negSucc 30)), ((Int.negSucc 6), (Int.ofNat 2), (Int.negSucc 6), (Int.negSucc 6))),
  (((Int.negSucc 12), (Int.negSucc 27)), ((Int.negSucc 8), (Int.negSucc 13), (Int.negSucc 6), (Int.negSucc 6))),
  (((Int.negSucc 12), (Int.negSucc 24)), ((Int.ofNat 5), (Int.negSucc 6), (Int.ofNat 5), (Int.ofNat 5))),
  (((Int.negSucc 12), (Int.negSucc 21)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 6))),
  (((Int.negSucc 12), (Int.negSucc 18)), ((Int.ofNat 12), (Int.negSucc 5), (Int.ofNat 0), (Int.ofNat 6))),
  (((Int.negSucc 12), (Int.negSucc 15)), ((Int.ofNat 15), (Int.negSucc 11), (Int.negSucc 2), (Int.ofNat 15))),
  (((Int.negSucc 12), (Int.negSucc 12)), ((Int.ofNat 27), (Int.ofNat 30), (Int.ofNat 15), (Int.ofNat 15))),
  (((Int.negSucc 12), (Int.negSucc 9)), ((Int.negSucc 2), (Int.ofNat 15), (Int.ofNat 15), (Int.negSucc 2))),
  (((Int.negSucc 12), (Int.negSucc 6)), ((Int.ofNat 18), (Int.ofNat 18), (Int.ofNat 36), (Int.ofNat 19))),
  (((Int.negSucc 12), (Int.negSucc 3)), ((Int.negSucc 19), (Int.ofNat 19), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.negSucc 12), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 21), (Int.ofNat 0))),
  (((Int.negSucc 11), (Int.negSucc 31)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 9))),
  (((Int.negSucc 11), (Int.negSucc 28)), ((Int.negSucc 8), (Int.negSucc 8), (Int.negSucc 17), (Int.negSucc 6))),
  (((Int.negSucc 11), (Int.negSucc 25)), ((Int.negSucc 6), (Int.negSucc 4), (Int.negSucc 1), (Int.negSucc 6))),
  (((Int.negSucc 11), (Int.negSucc 22)), ((Int.negSucc 5), (Int.negSucc 17), (Int.negSucc 5), (Int.negSucc 5))),
  (((Int.negSucc 11), (Int.negSucc 19)), ((Int.ofNat 0), (Int.negSucc 5), (Int.negSucc 5), (Int.negSucc 11))),
  (((Int.negSucc 11), (Int.negSucc 16)), ((Int.ofNat 18), (Int.ofNat 6), (Int.ofNat 18), (Int.negSucc 8))),
  (((Int.negSucc 11), (Int.negSucc 13)), ((Int.ofNat 27), (Int.ofNat 27), (Int.ofNat 54), (Int.ofNat 33))),
  (((Int.negSucc 11), (Int.negSucc 10)), ((Int.ofNat 15), (Int.ofNat 3), (Int.ofNat 12), (Int.ofNat 15))),
  (((Int.negSucc 11), (Int.negSucc 7)), ((Int.ofNat 1), (Int.ofNat 19), (Int.ofNat 19), (Int.ofNat 1))),
  (((Int.negSucc 11), (Int.negSucc 4)), ((Int.ofNat 18), (Int.ofNat 19), (Int.ofNat 19), (Int.ofNat 20))),
  (((Int.negSucc 11), (Int.negSucc 1)), ((Int.negSucc 20), (Int.negSucc 0), (Int.negSucc 20), (Int.negSucc 20))),
  (((Int.negSucc 11), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 20))),
  (((Int.negSucc 10), (Int.negSucc 29)), ((Int.ofNat 0), (Int.ofNat 9), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 10), (Int.negSucc 26)), ((Int.negSucc 1), (Int.ofNat 0), (Int.negSucc 8), (Int.negSucc 8))),
  (((Int.negSucc 10), (Int.negSucc 23)), ((Int.ofNat 5), (Int.negSucc 5), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 10), (Int.negSucc 20)), ((Int.ofNat 0), (Int.ofNat 6), (Int.ofNat 6), (Int.negSucc 5))),
  (((Int.negSucc 10), (Int.negSucc 17)), ((Int.ofNat 6), (Int.ofNat 12), (Int.ofNat 12), (Int.ofNat 18))),
  (((Int.negSucc 10), (Int.negSucc 14)), ((Int.ofNat 0), (Int.negSucc 26), (Int.negSucc 17), (Int.ofNat 0))),
  (((Int.negSucc 10), (Int.negSucc 11)), ((Int.ofNat 12), (Int.ofNat 0), (Int.ofNat 9), (Int.ofNat 27))),
  (((Int.negSucc 10), (Int.negSucc 8)), ((Int.negSucc 2), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 10), (Int.negSucc 5)), ((Int.ofNat 0), (Int.negSucc 18), (Int.negSucc 0), (Int.ofNat 19))),
  (((Int.negSucc 10), (Int.negSucc 2)), ((Int.negSucc 18), (Int.negSucc 19), (Int.negSucc 19), (Int.negSucc 20))),
  (((Int.negSucc 10), (Int.ofNat 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 21), (Int.ofNat 0))),
  (((Int.negSucc 10), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 21), (Int.ofNat 0))),
  (((Int.negSucc 9), (Int.negSucc 30)), ((Int.ofNat 0), (Int.negSucc 8), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 9), (Int.negSucc 27)), ((Int.ofNat 0), (Int.negSucc 8), (Int.negSucc 8), (Int.ofNat 0))),
  (((Int.negSucc 9), (Int.negSucc 24)), ((Int.ofNat 5), (Int.ofNat 3), (Int.ofNat 3), (Int.ofNat 3))),
  (((Int.negSucc 9), (Int.negSucc 21)), ((Int.ofNat 6), (Int.ofNat 0), (Int.negSucc 5), (Int.ofNat 12))),
  (((Int.negSucc 9), (Int.negSucc 15)), ((Int.negSucc 17), (Int.ofNat 21), (Int.ofNat 18), (Int.ofNat 0))),
  (((Int.negSucc 9), (Int.negSucc 12)), ((Int.ofNat 0), (Int.ofNat 9), (Int.ofNat 27), (Int.ofNat 0))),
  (((Int.negSucc 9), (Int.negSucc 9)), ((Int.negSucc 14), (Int.negSucc 2), (Int.negSucc 2), (Int.negSucc 2))),
  (((Int.negSucc 9), (Int.negSucc 6)), ((Int.negSucc 18), (Int.ofNat 0), (Int.ofNat 1), (Int.negSucc 19))),
  (((Int.negSucc 9), (Int.negSucc 0)), ((Int.ofNat 21), (Int.ofNat 1), (Int.negSucc 20), (Int.ofNat 0))),
  (((Int.negSucc 9), (Int.ofNat 2)), ((Int.ofNat 0), (Int.ofNat 21), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 9), (Int.ofNat 5)), ((Int.ofNat 20), (Int.ofNat 20), (Int.ofNat 20), (Int.ofNat 20))),
  (((Int.negSucc 8), (Int.negSucc 28)), ((Int.ofNat 0), (Int.ofNat 9), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 8), (Int.negSucc 25)), ((Int.negSucc 8), (Int.negSucc 8), (Int.ofNat 0), (Int.ofNat 3))),
  (((Int.negSucc 8), (Int.negSucc 22)), ((Int.negSucc 14), (Int.negSucc 14), (Int.negSucc 14), (Int.negSucc 2))),
  (((Int.negSucc 8), (Int.negSucc 19)), ((Int.negSucc 5), (Int.negSucc 5), (Int.negSucc 11), (Int.negSucc 17))),
  (((Int.negSucc 8), (Int.negSucc 16)), ((Int.ofNat 0), (Int.ofNat 12), (Int.ofNat 6), (Int.negSucc 11))),
  (((Int.negSucc 8), (Int.negSucc 13)), ((Int.ofNat 18), (Int.negSucc 8), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 8), (Int.negSucc 10)), ((Int.ofNat 9), (Int.ofNat 27), (Int.ofNat 0), (Int.negSucc 2))),
  (((Int.negSucc 8), (Int.negSucc 7)), ((Int.ofNat 15), (Int.ofNat 15), (Int.ofNat 15), (Int.negSucc 4))),
  (((Int.negSucc 8), (Int.negSucc 4)), ((Int.ofNat 19), (Int.ofNat 19), (Int.ofNat 38), (Int.ofNat 39)))
]
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N5 row1 chunk1: literal ready; arithmetic starts"
  out.flush)
theorem row1_chunk1_certificate : rowStep selected1 chunk1 acc0 = acc1_1 := by
  decide +kernel
#print axioms row1_chunk1_certificate
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_step1_1 : evalLaurent q U V acc1_1 =
    evalTerm q U V selected1 * evalLaurent q U V chunk1 + evalLaurent q U V acc0 := by
  rw [← row1_chunk1_certificate, evalLaurent_rowStep q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
#print axioms eval_step1_1
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N5 row1 chunk1: semantic complete"
  out.flush)
end PrimeCyclicity.N5Modern
