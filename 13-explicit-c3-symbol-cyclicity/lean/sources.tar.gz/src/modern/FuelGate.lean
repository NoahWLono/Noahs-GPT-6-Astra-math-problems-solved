module
public import modern.Numerator

@[expose] public section
namespace PrimeCyclicity
variable {D : Type*} [DivisionRing D]

/-- Primitive recursion; exhaustion preserves semantics by concatenation. -/
def mergeFuel : ℕ → List Term → List Term → List Term
  | 0, p, r => p ++ r
  | _+1, [], r => r
  | _+1, p, [] => p
  | n+1, t::p, s::r =>
    if t.1 = s.1 then (t.1, addCoeff t.2 s.2) :: mergeFuel n p r
    else if t.1.1 < s.1.1 ∨ (t.1.1 = s.1.1 ∧ t.1.2 < s.1.2) then
      t :: mergeFuel n p (s::r)
    else s :: mergeFuel n (t::p) r

theorem evalLaurent_mergeFuel {k : Type*} [CommRing k] [Algebra k D]
    (q : k) (U V : Dˣ) (n : ℕ) (p r : List Term) :
    evalLaurent q U V (mergeFuel n p r) = evalLaurent q U V p + evalLaurent q U V r := by
  induction n generalizing p r with
  | zero => simp [mergeFuel, evalLaurent_append]
  | succ n ih =>
    cases p with
    | nil => simp [mergeFuel, evalLaurent]
    | cons t p =>
      cases r with
      | nil => simp [mergeFuel, evalLaurent]
      | cons s r =>
        rw [mergeFuel]
        split_ifs with h hlt
        · have he : evalTerm q U V (t.1, addCoeff t.2 s.2) =
              evalTerm q U V t + evalTerm q U V s := by
            simp only [evalTerm, evalCoeff_add, map_add, add_mul]
            rw [h]
          change evalTerm q U V (t.1, addCoeff t.2 s.2) +
              evalLaurent q U V (mergeFuel n p r) = _
          rw [he, ih]
          simp only [evalLaurent, List.map_cons, List.sum_cons]
          ac_rfl
        · change evalTerm q U V t + evalLaurent q U V (mergeFuel n p (s::r)) = _
          rw [ih]
          simp [evalLaurent, add_assoc]
        · change evalTerm q U V s + evalLaurent q U V (mergeFuel n (t::p) r) = _
          rw [ih]
          simp only [evalLaurent, List.map_cons, List.sum_cons]
          ac_rfl

def rowStep (t : Term) (r p : List Term) : List Term :=
  trimLaurent (mergeFuel (r.length+p.length) (r.map (mulTerm t)) p)

theorem evalLaurent_rowStep {k : Type*} [CommRing k] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
    (t : Term) (r p : List Term) :
    evalLaurent q U V (rowStep t r p) =
      evalTerm q U V t * evalLaurent q U V r + evalLaurent q U V p := by
  rw [rowStep, evalLaurent_trim, evalLaurent_mergeFuel]
  congr 1
  induction r with
  | nil => simp [evalLaurent]
  | cons s r ih =>
    simp only [List.map_cons, evalLaurent, List.sum_cons]
    rw [evalTerm_mul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
    change _ + evalLaurent q U V (r.map (mulTerm t)) = _
    rw [ih]
    simp [evalLaurent, mul_add]

#print axioms evalLaurent_mergeFuel
#print axioms evalLaurent_rowStep
end PrimeCyclicity

set_option maxRecDepth 100000
set_option maxHeartbeats 2000000
namespace PrimeCyclicity
def row1 : List Term := [
  (((Int.ofNat 0), (Int.negSucc 7)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.negSucc 8)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 1), (Int.negSucc 5)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 6)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 1), (Int.negSucc 0))),
  (((Int.ofNat 2), (Int.negSucc 3)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.ofNat 3), (Int.negSucc 7)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 3), (Int.negSucc 4)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 1))),
  (((Int.ofNat 3), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.negSucc 5)), ((Int.ofNat 0), (Int.ofNat 1), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 4), (Int.negSucc 2)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.negSucc 0))),
  (((Int.ofNat 4), (Int.ofNat 0)), ((Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.negSucc 6)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 5), (Int.negSucc 0)), ((Int.ofNat 2), (Int.ofNat 3), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 5), (Int.ofNat 2)), ((Int.ofNat 0), (Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 6), (Int.negSucc 4)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 1), (Int.ofNat 0))),
  (((Int.ofNat 6), (Int.negSucc 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.ofNat 6), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 6), (Int.ofNat 4)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 7), (Int.negSucc 5)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 7), (Int.negSucc 2)), ((Int.ofNat 1), (Int.ofNat 1), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 7), (Int.ofNat 0)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 7), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 1), (Int.negSucc 0))),
  (((Int.ofNat 7), (Int.ofNat 6)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.ofNat 8), (Int.negSucc 3)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 1), (Int.negSucc 0))),
  (((Int.ofNat 8), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 1))),
  (((Int.ofNat 8), (Int.ofNat 2)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 8), (Int.ofNat 5)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 1))),
  (((Int.ofNat 8), (Int.ofNat 8)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0))),
  (((Int.ofNat 9), (Int.negSucc 4)), ((Int.ofNat 0), (Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 9), (Int.negSucc 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 9), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 9), (Int.ofNat 7)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 2))),
  (((Int.ofNat 9), (Int.ofNat 10)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 10), (Int.negSucc 2)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 10), (Int.ofNat 3)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 10), (Int.ofNat 9)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 11), (Int.negSucc 3)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 11), (Int.negSucc 0)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 11), (Int.ofNat 5)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.ofNat 11), (Int.ofNat 8)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 11), (Int.ofNat 11)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 12), (Int.negSucc 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 1), (Int.ofNat 2))),
  (((Int.ofNat 12), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 1), (Int.ofNat 0))),
  (((Int.ofNat 12), (Int.ofNat 4)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 12), (Int.ofNat 7)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 12), (Int.ofNat 10)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 13), (Int.negSucc 2)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 13), (Int.ofNat 0)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 1))),
  (((Int.ofNat 13), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.ofNat 13), (Int.ofNat 6)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 1), (Int.ofNat 2))),
  (((Int.ofNat 13), (Int.ofNat 9)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 14), (Int.negSucc 0)), ((Int.ofNat 0), (Int.negSucc 1), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 14), (Int.ofNat 2)), ((Int.ofNat 0), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 0))),
  (((Int.ofNat 14), (Int.ofNat 5)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 14), (Int.ofNat 8)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 15), (Int.negSucc 1)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 15), (Int.ofNat 4)), ((Int.negSucc 0), (Int.negSucc 2), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.ofNat 15), (Int.ofNat 7)), ((Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 16), (Int.ofNat 0)), ((Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.ofNat 16), (Int.ofNat 3)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 16), (Int.ofNat 6)), ((Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 17), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 17), (Int.ofNat 2)), ((Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 17), (Int.ofNat 5)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 18), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 1), (Int.negSucc 0))),
  (((Int.ofNat 18), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 19), (Int.ofNat 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 19), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 20), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
def row2 : List Term := [
  (((Int.negSucc 0), (Int.negSucc 6)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.negSucc 7)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 2))),
  (((Int.ofNat 0), (Int.negSucc 4)), ((Int.negSucc 3), (Int.negSucc 3), (Int.negSucc 3), (Int.negSucc 3))),
  (((Int.ofNat 1), (Int.negSucc 8)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 1), (Int.negSucc 5)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 1), (Int.negSucc 2)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 6)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 2), (Int.negSucc 0))),
  (((Int.ofNat 2), (Int.negSucc 3)), ((Int.ofNat 4), (Int.ofNat 2), (Int.ofNat 3), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 0)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 3), (Int.negSucc 7)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 3), (Int.negSucc 4)), ((Int.ofNat 2), (Int.ofNat 1), (Int.ofNat 3), (Int.ofNat 1))),
  (((Int.ofNat 3), (Int.negSucc 1)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 3), (Int.ofNat 4))),
  (((Int.ofNat 3), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 3), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.negSucc 5)), ((Int.negSucc 1), (Int.negSucc 0), (Int.negSucc 2), (Int.negSucc 2))),
  (((Int.ofNat 4), (Int.negSucc 2)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.negSucc 0))),
  (((Int.ofNat 4), (Int.ofNat 0)), ((Int.ofNat 2), (Int.ofNat 6), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 4), (Int.ofNat 3)), ((Int.ofNat 0), (Int.negSucc 3), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.negSucc 6)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 5), (Int.negSucc 3)), ((Int.ofNat 0), (Int.negSucc 1), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 5), (Int.negSucc 0)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 2), (Int.ofNat 1))),
  (((Int.ofNat 5), (Int.ofNat 2)), ((Int.negSucc 1), (Int.negSucc 3), (Int.negSucc 1), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.ofNat 5)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 6), (Int.negSucc 4)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 2))),
  (((Int.ofNat 6), (Int.negSucc 1)), ((Int.negSucc 3), (Int.negSucc 4), (Int.negSucc 3), (Int.negSucc 1))),
  (((Int.ofNat 6), (Int.ofNat 1)), ((Int.ofNat 2), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 6), (Int.ofNat 4)), ((Int.negSucc 2), (Int.negSucc 5), (Int.negSucc 3), (Int.negSucc 3))),
  (((Int.ofNat 6), (Int.ofNat 7)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 7), (Int.negSucc 5)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 7), (Int.negSucc 2)), ((Int.negSucc 2), (Int.negSucc 0), (Int.negSucc 2), (Int.ofNat 1))),
  (((Int.ofNat 7), (Int.ofNat 0)), ((Int.negSucc 3), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 7), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 2), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 7), (Int.ofNat 6)), ((Int.negSucc 1), (Int.ofNat 2), (Int.ofNat 3), (Int.ofNat 0))),
  (((Int.ofNat 7), (Int.ofNat 9)), ((Int.negSucc 3), (Int.negSucc 3), (Int.negSucc 3), (Int.negSucc 3))),
  (((Int.ofNat 8), (Int.negSucc 3)), ((Int.ofNat 0), (Int.ofNat 2), (Int.negSucc 2), (Int.negSucc 0))),
  (((Int.ofNat 8), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.ofNat 8), (Int.ofNat 2)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 8), (Int.ofNat 5)), ((Int.negSucc 3), (Int.negSucc 4), (Int.negSucc 2), (Int.negSucc 1))),
  (((Int.ofNat 8), (Int.ofNat 8)), ((Int.negSucc 3), (Int.negSucc 3), (Int.ofNat 0), (Int.negSucc 1))),
  (((Int.ofNat 8), (Int.ofNat 11)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 9), (Int.negSucc 4)), ((Int.ofNat 0), (Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 9), (Int.negSucc 1)), ((Int.ofNat 2), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 9), (Int.ofNat 4)), ((Int.ofNat 4), (Int.ofNat 5), (Int.ofNat 6), (Int.ofNat 6))),
  (((Int.ofNat 9), (Int.ofNat 7)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 2))),
  (((Int.ofNat 9), (Int.ofNat 10)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 10), (Int.negSucc 2)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0), (Int.negSucc 3))),
  (((Int.ofNat 10), (Int.ofNat 0)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 10), (Int.ofNat 3)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 10), (Int.ofNat 6)), ((Int.ofNat 0), (Int.negSucc 1), (Int.negSucc 3), (Int.negSucc 3))),
  (((Int.ofNat 10), (Int.ofNat 9)), ((Int.ofNat 3), (Int.ofNat 2), (Int.ofNat 3), (Int.ofNat 1))),
  (((Int.ofNat 10), (Int.ofNat 12)), ((Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.ofNat 11), (Int.negSucc 3)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 11), (Int.negSucc 0)), ((Int.ofNat 3), (Int.ofNat 6), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 11), (Int.ofNat 2)), ((Int.negSucc 3), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 11), (Int.ofNat 5)), ((Int.ofNat 4), (Int.ofNat 4), (Int.ofNat 3), (Int.ofNat 2))),
  (((Int.ofNat 11), (Int.ofNat 8)), ((Int.ofNat 2), (Int.ofNat 4), (Int.negSucc 0), (Int.ofNat 1))),
  (((Int.ofNat 11), (Int.ofNat 11)), ((Int.negSucc 2), (Int.negSucc 3), (Int.negSucc 3), (Int.negSucc 3))),
  (((Int.ofNat 12), (Int.negSucc 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 2))),
  (((Int.ofNat 12), (Int.ofNat 1)), ((Int.negSucc 1), (Int.negSucc 3), (Int.negSucc 5), (Int.ofNat 0))),
  (((Int.ofNat 12), (Int.ofNat 4)), ((Int.ofNat 2), (Int.ofNat 1), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 12), (Int.ofNat 7)), ((Int.ofNat 3), (Int.negSucc 0), (Int.ofNat 0), (Int.negSucc 1))),
  (((Int.ofNat 12), (Int.ofNat 10)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 13), (Int.negSucc 2)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 13), (Int.ofNat 0)), ((Int.ofNat 2), (Int.ofNat 4), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 13), (Int.ofNat 3)), ((Int.ofNat 2), (Int.ofNat 2), (Int.negSucc 2), (Int.negSucc 1))),
  (((Int.ofNat 13), (Int.ofNat 6)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 3), (Int.ofNat 2))),
  (((Int.ofNat 13), (Int.ofNat 9)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 1), (Int.ofNat 1))),
  (((Int.ofNat 14), (Int.negSucc 0)), ((Int.negSucc 1), (Int.negSucc 3), (Int.negSucc 2), (Int.negSucc 2))),
  (((Int.ofNat 14), (Int.ofNat 2)), ((Int.ofNat 0), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 0))),
  (((Int.ofNat 14), (Int.ofNat 5)), ((Int.negSucc 0), (Int.negSucc 4), (Int.negSucc 3), (Int.negSucc 3))),
  (((Int.ofNat 14), (Int.ofNat 8)), ((Int.negSucc 3), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 15), (Int.negSucc 1)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 15), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 4), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 15), (Int.ofNat 4)), ((Int.negSucc 2), (Int.negSucc 0), (Int.ofNat 0), (Int.negSucc 1))),
  (((Int.ofNat 15), (Int.ofNat 7)), ((Int.ofNat 2), (Int.ofNat 4), (Int.ofNat 4), (Int.ofNat 4))),
  (((Int.ofNat 16), (Int.ofNat 0)), ((Int.negSucc 4), (Int.negSucc 4), (Int.negSucc 2), (Int.negSucc 3))),
  (((Int.ofNat 16), (Int.ofNat 3)), ((Int.ofNat 2), (Int.ofNat 1), (Int.ofNat 5), (Int.ofNat 1))),
  (((Int.ofNat 16), (Int.ofNat 6)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 2))),
  (((Int.ofNat 17), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 17), (Int.ofNat 2)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 3), (Int.ofNat 1))),
  (((Int.ofNat 17), (Int.ofNat 5)), ((Int.ofNat 2), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 18), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.ofNat 18), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 4), (Int.ofNat 1))),
  (((Int.ofNat 19), (Int.ofNat 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 19), (Int.ofNat 3)), ((Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 20), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem row1_certificate : rowStep (((Int.ofNat 10), (Int.ofNat 1)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))) numerator [] = row1 := by
  decide +kernel
#print axioms row1_certificate
theorem row2_certificate : rowStep (((Int.ofNat 9), (Int.ofNat 2)), ((Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))) numerator row1 = row2 := by
  decide +kernel
#print axioms row2_certificate
end PrimeCyclicity
