module
public import modern.N3Row67
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
set_option profiler true
namespace PrimeCyclicity.N3Modern
variable {k D : Type*} [CommRing k] [DivisionRing D] [Algebra k D]
    (q : k) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap k D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N3 chain row68: loaded"
  out.flush)
def processed68 : List Term := (((Int.negSucc 8), (Int.negSucc 9)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))) :: processed67
def acc68 : List Term := N3PilotInterior.after
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N3 chain row68: arithmetic starts"
  out.flush)
theorem row68_certificate : rowStep (((Int.negSucc 8), (Int.negSucc 9)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))) N2Modern.acc69 acc67 = acc68 := by
  exact N3PilotInterior.row_certificate
#print axioms row68_certificate
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_acc68 : evalLaurent q U V acc68 =
    evalLaurent q U V processed68 * (evalLaurent q U V numerator)^2 := by
  rw [← row68_certificate, evalLaurent_rowStep q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV, ← N2Modern.numerator_squared q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
  rw [eval_acc67 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
  change _ = (evalTerm q U V (((Int.negSucc 8), (Int.negSucc 9)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))) + evalLaurent q U V processed67) * _
  exact (add_mul _ _ _).symm
#print axioms eval_acc68
#eval (show IO Unit from do
  let out ← IO.getStdout
  out.putStrLn "N3 chain row68: semantic complete"
  out.flush)
end PrimeCyclicity.N3Modern
