module
public import FifthRoots
public import Mathlib.Tactic.NoncommRing

@[expose] public section
namespace TwoCoefficientObstruction
variable {F D : Type*} [Field F] [DivisionRing D] [Algebra F D]

def phase : ℕ → ℕ
  | 0 => 0
  | n + 1 => phase n + n

 theorem skew_pow_mul (q : F) (a b : D) (h : b * a = q • (a * b)) (n : ℕ) :
    b ^ n * a = (q ^ n) • (a * b ^ n) := by
  induction n with
  | zero => simp
  | succ n ih =>
    calc
      b ^ (n + 1) * a = b * (b ^ n * a) := by rw [pow_succ', mul_assoc]
      _ = b * ((q ^ n) • (a * b ^ n)) := by rw [ih]
      _ = (q ^ n) • ((b * a) * b ^ n) := by rw [mul_smul_comm, ← mul_assoc]
      _ = (q ^ n) • ((q • (a * b)) * b ^ n) := by rw [h]
      _ = (q ^ (n + 1)) • (a * b ^ (n + 1)) := by
        simp only [smul_mul_assoc, smul_smul, pow_succ, mul_assoc]
        rw [(Commute.self_pow b n).eq]

 theorem skew_mul_pow (q : F) (a b : D) (h : b * a = q • (a * b)) (n : ℕ) :
    (a * b) ^ n = (q ^ phase n) • (a ^ n * b ^ n) := by
  induction n with
  | zero => simp [phase]
  | succ n ih =>
    calc
      (a * b) ^ (n + 1) = ((q ^ phase n) • (a ^ n * b ^ n)) * (a * b) := by
        rw [pow_succ, ih]
      _ = (q ^ phase n) • (a ^ n * (b ^ n * a) * b) := by
        simp only [smul_mul_assoc, mul_assoc]
      _ = (q ^ phase n) • (a ^ n * ((q ^ n) • (a * b ^ n)) * b) := by
        rw [skew_pow_mul q a b h]
      _ = (q ^ phase (n + 1)) • (a ^ (n + 1) * b ^ (n + 1)) := by
        simp only [mul_smul_comm, smul_mul_assoc, smul_smul, phase, pow_add, pow_succ,
          mul_assoc]

 theorem skew_mul_fifth (q : F) (a b : D) (h : b * a = q • (a * b)) :
    (a * b) ^ 5 = (q ^ 10) • (a ^ 5 * b ^ 5) := by
  simpa [phase] using skew_mul_pow q a b h 5

#print axioms skew_mul_fifth
end TwoCoefficientObstruction
