module
public import Leaves
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
namespace CompactLaurentBridge
open PrimeCyclicity
variable {K D : Type*} [CommRing K] [DivisionRing D] [Algebra K D]
    (q : K) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap K D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
def w : List Term := [
  (((Int.negSucc 0), (Int.negSucc 0)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0)))
]
theorem w_certificate : fastMul vi ui = w := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_w : evalLaurent q U V w = evalLaurent q U V vi * evalLaurent q U V ui := by
  rw [← w_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def wi : List Term := [
  (((Int.ofNat 1), (Int.ofNat 1)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem wi_certificate : fastMul u v = wi := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_wi : evalLaurent q U V wi = evalLaurent q U V u * evalLaurent q U V v := by
  rw [← wi_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def w2 : List Term := [
  (((Int.negSucc 1), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0)))
]
theorem w2_certificate : fastMul w w = w2 := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_w2 : evalLaurent q U V w2 = evalLaurent q U V w * evalLaurent q U V w := by
  rw [← w2_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def w4 : List Term := [
  (((Int.negSucc 3), (Int.negSucc 3)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem w4_certificate : fastMul w2 w2 = w4 := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_w4 : evalLaurent q U V w4 = evalLaurent q U V w2 * evalLaurent q U V w2 := by
  rw [← w4_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def z : List Term := [
  (((Int.negSucc 4), (Int.negSucc 4)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem z_certificate : fastMul w4 w = z := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_z : evalLaurent q U V z = evalLaurent q U V w4 * evalLaurent q U V w := by
  rw [← z_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def a0 : List Term := [
  (((Int.negSucc 0), (Int.negSucc 0)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 1), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem a0_certificate : subL u w = a0 := by decide +kernel
theorem eval_a0 : evalLaurent q U V a0 = evalLaurent q U V u - evalLaurent q U V w := by
  rw [← a0_certificate, eval_sub q U V]
def a1 : List Term := [
  (((Int.negSucc 0), (Int.negSucc 0)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.ofNat 1)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem a1_certificate : subL v w = a1 := by decide +kernel
theorem eval_a1 : evalLaurent q U V a1 = evalLaurent q U V v - evalLaurent q U V w := by
  rw [← a1_certificate, eval_sub q U V]
def b0 : List Term := [
  (((Int.negSucc 0), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 1)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem b0_certificate : subL ui wi = b0 := by decide +kernel
theorem eval_b0 : evalLaurent q U V b0 = evalLaurent q U V ui - evalLaurent q U V wi := by
  rw [← b0_certificate, eval_sub q U V]
def b1 : List Term := [
  (((Int.ofNat 0), (Int.negSucc 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 1)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem b1_certificate : subL vi wi = b1 := by decide +kernel
theorem eval_b1 : evalLaurent q U V b1 = evalLaurent q U V vi - evalLaurent q U V wi := by
  rw [← b1_certificate, eval_sub q U V]
def a2_ad : List Term := [
  (((Int.negSucc 1), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 2), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem a2_ad_certificate : fastMul a0 a0 = a2_ad := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_a2_ad : evalLaurent q U V a2_ad = evalLaurent q U V a0 * evalLaurent q U V a0 := by
  rw [← a2_ad_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def a2_be : List Term := [
  (((Int.negSucc 1), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem a2_be_certificate : fastMul a1 a1 = a2_be := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_a2_be : evalLaurent q U V a2_be = evalLaurent q U V a1 * evalLaurent q U V a1 := by
  rw [← a2_be_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def a2_ae : List Term := [
  (((Int.negSucc 1), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.negSucc 0)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 1), (Int.ofNat 1)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem a2_ae_certificate : fastMul a0 a1 = a2_ae := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_a2_ae : evalLaurent q U V a2_ae = evalLaurent q U V a0 * evalLaurent q U V a1 := by
  rw [← a2_ae_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def a2_bd : List Term := [
  (((Int.negSucc 1), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 0)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.negSucc 0)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 1)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0)))
]
theorem a2_bd_certificate : fastMul a1 a0 = a2_bd := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_a2_bd : evalLaurent q U V a2_bd = evalLaurent q U V a1 * evalLaurent q U V a0 := by
  rw [← a2_bd_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def a2_0 : List Term := [
  (((Int.negSucc 0), (Int.ofNat 0)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 0), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.ofNat 2)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem a2_0_certificate : subL a2_ad a2_be = a2_0 := by decide +kernel
theorem eval_a2_0 : evalLaurent q U V a2_0 = evalLaurent q U V a2_ad - evalLaurent q U V a2_be := by
  rw [← a2_0_certificate, eval_sub q U V]
def a2_sum : List Term := [
  (((Int.negSucc 1), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 1), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0)))
]
theorem a2_sum_certificate : addL a2_ae a2_bd = a2_sum := by decide +kernel
theorem eval_a2_sum : evalLaurent q U V a2_sum = evalLaurent q U V a2_ae + evalLaurent q U V a2_bd := by
  rw [← a2_sum_certificate, eval_add q U V]
end CompactLaurentBridge
