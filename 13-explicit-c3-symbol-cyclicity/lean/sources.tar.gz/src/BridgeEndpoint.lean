module
public import ScalarCoordinates
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring
@[expose] public section
namespace ConcreteCoordinateBridge
open PrimeCyclicity Module
variable {K A : Type*} [Field K] [DivisionRing A] [Algebra K A]
variable (b : Basis (Fin 5 × Fin 5) K A) (U V : Aˣ) (x y : K)
variable (hb : ∀ ij, b ij = (U : A) ^ ij.1.val * (V : A) ^ ij.2.val)
variable (hU : (U : A) ^ 5 = algebraMap K A x)
variable (hV : (V : A) ^ 5 = algebraMap K A y)

include hb hU hV

theorem numerator_coordinate13 (q : K) (hx : x ≠ 0) (hy : y ≠ 0) :
    b.repr (evalLaurent q U V numerator) (1, 3) =
      q * (x ^ 2 * y + x * y ^ 2 - 2) / (x ^ 2 * y ^ 2) := by
  rw [repr_evalLaurent b U V x y hb hU hV, numerator_coordinate13_raw]
  field_simp [hx, hy]
  <;> ring

theorem numerator_coordinate23 (q : K) (hx : x ≠ 0) (hy : y ≠ 0) :
    b.repr (evalLaurent q U V numerator) (2, 3) =
      -q ^ 3 * (2 * x ^ 2 * y - x * y ^ 2 - 1) / (x * y ^ 2) := by
  rw [repr_evalLaurent b U V x y hb hU hV, numerator_coordinate23_raw]
  field_simp [hx, hy]
  <;> ring

omit hU hV in
theorem repr_scalar (c : K) (ij : Fin 5 × Fin 5) (hij : ij ≠ (0, 0)) :
    b.repr (algebraMap K A c) ij = 0 := by
  have h₀ : b (0, 0) = 1 := by simpa using hb (0, 0)
  have hc : algebraMap K A c = c • b (0, 0) := by simp [h₀, Algebra.smul_def]
  rw [hc]
  simp [Basis.repr_self_apply, Ne.symm hij]

/-- The concrete numerator cannot be a scalar, using its derived coordinates. -/
theorem evaluated_numerator_not_scalar [CharZero K]
    (q : K) (hq : IsPrimitiveRoot q 5)
    (hUV : (U : A) * V = q • ((V : A) * U)) :
    ¬ ∃ c : K, evalLaurent q U V numerator = algebraMap K A c := by
  have hx : x ≠ 0 := by
    intro hx
    have hz : (U : A) ^ 5 = 0 := by simpa [hx] using hU
    exact (pow_ne_zero 5 U.ne_zero) hz
  have hy : y ≠ 0 := by
    intro hy
    have hz : (V : A) ^ 5 = 0 := by simpa [hy] using hV
    exact (pow_ne_zero 5 V.ne_zero) hz
  have hq0 : q ≠ 0 := hq.ne_zero (by decide)
  rintro ⟨c, hc⟩
  have hz13 : b.repr (evalLaurent q U V numerator) (1, 3) = 0 := by
    rw [hc]
    exact repr_scalar b U V hb c (1, 3) (by decide)
  have hz23 : b.repr (evalLaurent q U V numerator) (2, 3) = 0 := by
    rw [hc]
    exact repr_scalar b U V hb c (2, 3) (by decide)
  rw [numerator_coordinate13 b U V x y hb hU hV q hx hy] at hz13
  rw [numerator_coordinate23 b U V x y hb hU hV q hx hy] at hz23
  have he1 : x ^ 2 * y + x * y ^ 2 = 2 := by
    have h := (div_eq_zero_iff.mp hz13).resolve_right (mul_ne_zero (pow_ne_zero 2 hx) (pow_ne_zero 2 hy))
    exact sub_eq_zero.mp ((mul_eq_zero.mp h).resolve_left hq0)
  have he2 : 2 * x ^ 2 * y - x * y ^ 2 = 1 := by
    have h := (div_eq_zero_iff.mp hz23).resolve_right (mul_ne_zero hx (pow_ne_zero 2 hy))
    exact sub_eq_zero.mp ((mul_eq_zero.mp h).resolve_left (neg_ne_zero.mpr (pow_ne_zero 3 hq0)))
  exact TwoCoefficientObstruction.two_coefficient_equations_impossible q hq U V hUV x y hU hV he1 he2

#print axioms evaluated_numerator_not_scalar
#print evaluated_numerator_not_scalar
end ConcreteCoordinateBridge
