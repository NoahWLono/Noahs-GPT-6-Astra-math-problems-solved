module
public import modern.Algebra

/- Frozen 75-term expected output only. No power identity is imported or asserted. -/
@[expose] public section
namespace FrozenCentralOutput75
open PrimeCyclicity

def candidateOutput75 : List Term := [
  (((Int.negSucc 49), (Int.negSucc 44)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 44), (Int.negSucc 49)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 44), (Int.negSucc 34)), ((Int.ofNat 3), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 39), (Int.negSucc 39)), ((Int.ofNat 14), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 39), (Int.negSucc 24)), ((Int.negSucc 5), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 34), (Int.negSucc 44)), ((Int.ofNat 3), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 34), (Int.negSucc 29)), ((Int.negSucc 38), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 34), (Int.negSucc 14)), ((Int.ofNat 6), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 29), (Int.negSucc 34)), ((Int.negSucc 38), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 29), (Int.negSucc 19)), ((Int.ofNat 84), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 29), (Int.negSucc 4)), ((Int.negSucc 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 24), (Int.negSucc 39)), ((Int.negSucc 5), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 24), (Int.negSucc 24)), ((Int.ofNat 60), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 24), (Int.negSucc 9)), ((Int.negSucc 116), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 24), (Int.ofNat 5)), ((Int.negSucc 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 19), (Int.negSucc 29)), ((Int.ofNat 84), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 19), (Int.negSucc 14)), ((Int.negSucc 89), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 19), (Int.ofNat 0)), ((Int.ofNat 138), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 19), (Int.ofNat 15)), ((Int.ofNat 6), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 14), (Int.negSucc 34)), ((Int.ofNat 6), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 14), (Int.negSucc 19)), ((Int.negSucc 89), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 14), (Int.negSucc 4)), ((Int.ofNat 21), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 14), (Int.ofNat 10)), ((Int.negSucc 116), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 14), (Int.ofNat 25)), ((Int.negSucc 5), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 9), (Int.negSucc 24)), ((Int.negSucc 116), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 9), (Int.negSucc 9)), ((Int.ofNat 192), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 9), (Int.ofNat 5)), ((Int.ofNat 21), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 9), (Int.ofNat 20)), ((Int.ofNat 84), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 9), (Int.ofNat 35)), ((Int.ofNat 3), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 4), (Int.negSucc 29)), ((Int.negSucc 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 4), (Int.negSucc 14)), ((Int.ofNat 21), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 4), (Int.ofNat 0)), ((Int.negSucc 119), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 4), (Int.ofNat 15)), ((Int.negSucc 89), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 4), (Int.ofNat 30)), ((Int.negSucc 38), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 4), (Int.ofNat 45)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.negSucc 19)), ((Int.ofNat 138), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.negSucc 4)), ((Int.negSucc 119), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.ofNat 10)), ((Int.ofNat 192), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.ofNat 25)), ((Int.ofNat 60), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.ofNat 40)), ((Int.ofNat 14), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.negSucc 24)), ((Int.negSucc 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.negSucc 9)), ((Int.ofNat 21), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.ofNat 5)), ((Int.negSucc 119), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.ofNat 20)), ((Int.negSucc 89), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.ofNat 35)), ((Int.negSucc 38), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.ofNat 50)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 10), (Int.negSucc 14)), ((Int.negSucc 116), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 10), (Int.ofNat 0)), ((Int.ofNat 192), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 10), (Int.ofNat 15)), ((Int.ofNat 21), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 10), (Int.ofNat 30)), ((Int.ofNat 84), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 10), (Int.ofNat 45)), ((Int.ofNat 3), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 15), (Int.negSucc 19)), ((Int.ofNat 6), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 15), (Int.negSucc 4)), ((Int.negSucc 89), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 15), (Int.ofNat 10)), ((Int.ofNat 21), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 15), (Int.ofNat 25)), ((Int.negSucc 116), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 15), (Int.ofNat 40)), ((Int.negSucc 5), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 20), (Int.negSucc 9)), ((Int.ofNat 84), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 20), (Int.ofNat 5)), ((Int.negSucc 89), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 20), (Int.ofNat 20)), ((Int.ofNat 138), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 20), (Int.ofNat 35)), ((Int.ofNat 6), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 25), (Int.negSucc 14)), ((Int.negSucc 5), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 25), (Int.ofNat 0)), ((Int.ofNat 60), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 25), (Int.ofNat 15)), ((Int.negSucc 116), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 25), (Int.ofNat 30)), ((Int.negSucc 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 30), (Int.negSucc 4)), ((Int.negSucc 38), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 30), (Int.ofNat 10)), ((Int.ofNat 84), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 30), (Int.ofNat 25)), ((Int.negSucc 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 35), (Int.negSucc 9)), ((Int.ofNat 3), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 35), (Int.ofNat 5)), ((Int.negSucc 38), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 35), (Int.ofNat 20)), ((Int.ofNat 6), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 40), (Int.ofNat 0)), ((Int.ofNat 14), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 40), (Int.ofNat 15)), ((Int.negSucc 5), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 45), (Int.negSucc 4)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 45), (Int.ofNat 10)), ((Int.ofNat 3), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 50), (Int.ofNat 5)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]

/-- Only a support certificate, not a statement about the numerator's fifth power. -/
theorem candidateOutput75_support :
    ∀ t ∈ candidateOutput75, (5 : ℤ) ∣ t.1.1 ∧ (5 : ℤ) ∣ t.1.2 := by decide

theorem candidateOutput75_length : candidateOutput75.length = 75 := by decide

/-- Every coefficient is an ordinary integer, independent of q. -/
theorem candidateOutput75_coefficients :
    ∀ t ∈ candidateOutput75, t.2.2.1 = 0 ∧ t.2.2.2.1 = 0 ∧ t.2.2.2.2 = 0 := by decide
end FrozenCentralOutput75
