module
public import FixedAlgebra

@[expose] public section
noncomputable section
open Module Submodule
namespace C3BasisDescent
variable {K A : Type*} [Field K] [Ring A] [Nontrivial A] [Algebra K A]

/-- The center descends from K to the actual fixed scalar field. -/
theorem center_fixedAlgebra
    (σ : A ≃+* A) (τ : K ≃+* K)
    (hsemi : ∀ (c : K) (a : A), σ (c • a) = τ c • σ a)
    (hspan : span K {a : A | σ a = a} = ⊤)
    (hcenter : ∀ a : A, (∀ z : A, a * z = z * a) ↔
      ∃ c : K, algebraMap K A c = a)
    (d : fixedAlgebra σ τ hsemi) :
    (∀ z : fixedAlgebra σ τ hsemi, d * z = z * d) ↔
      ∃ c : fixedField τ, algebraMap (fixedField τ) (fixedAlgebra σ τ hsemi) c = d := by
  constructor
  · intro hd
    let C : Submodule K A := {
      carrier := {a | (d : A) * a = a * d}
      zero_mem' := by simp
      add_mem' := fun ha hb => by
        change (d : A) * (_ + _) = (_ + _) * d
        rw [mul_add, add_mul, ha, hb]
      smul_mem' := fun c a ha => by
        change (d : A) * (c • a) = (c • a) * d
        rw [mul_smul_comm, smul_mul_assoc, ha] }
    have hle : span K {a : A | σ a = a} ≤ C := by
      apply span_le.mpr
      intro a ha
      exact congrArg Subtype.val (hd ⟨a, ha⟩)
    have hcA : ∀ a : A, (d : A) * a = a * d := by
      intro a
      exact hle (hspan ▸ Submodule.mem_top)
    obtain ⟨c, hc⟩ := (hcenter (d : A)).mp hcA
    have hτ : τ c = c := by
      apply (algebraMap K A).injective
      have hs := hsemi c (1 : A)
      simp only [Algebra.smul_def, mul_one, map_one] at hs
      calc
        algebraMap K A (τ c) = σ (algebraMap K A c) := hs.symm
        _ = σ (d : A) := congrArg σ hc
        _ = d := d.property
        _ = algebraMap K A c := hc.symm
    refine ⟨⟨c, hτ⟩, ?_⟩
    apply Subtype.ext
    exact hc
  · rintro ⟨c, rfl⟩ z
    exact Algebra.commutes c z

end C3BasisDescent
