module
public import Computation01
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
namespace CompactLaurentBridge
open PrimeCyclicity
variable {K D : Type*} [CommRing K] [DivisionRing D] [Algebra K D]
    (q : K) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap K D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V)
def a2_1 : List Term := [
  (((Int.negSucc 1), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.ofNat 2)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0)))
]
theorem a2_1_certificate : subL a2_sum a2_be = a2_1 := by decide +kernel
theorem eval_a2_1 : evalLaurent q U V a2_1 = evalLaurent q U V a2_sum - evalLaurent q U V a2_be := by
  rw [← a2_1_certificate, eval_sub q U V]
def a4_ad : List Term := [
  (((Int.negSucc 1), (Int.ofNat 0)), ((Int.negSucc 0), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 0))),
  (((Int.negSucc 0), (Int.negSucc 0)), ((Int.ofNat 2), (Int.ofNat 3), (Int.ofNat 2), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.negSucc 1)), ((Int.negSucc 0), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 0))),
  (((Int.ofNat 0), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.ofNat 0), (Int.ofNat 4)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 0)), ((Int.ofNat 0), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.ofNat 2), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 2), (Int.ofNat 2)), ((Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem a4_ad_certificate : fastMul a2_0 a2_0 = a4_ad := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_a4_ad : evalLaurent q U V a4_ad = evalLaurent q U V a2_0 * evalLaurent q U V a2_0 := by
  rw [← a4_ad_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def a4_be : List Term := [
  (((Int.negSucc 3), (Int.negSucc 3)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 1), (Int.negSucc 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.negSucc 1), (Int.ofNat 0)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.negSucc 0)), ((Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.negSucc 1)), ((Int.negSucc 0), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 0))),
  (((Int.ofNat 0), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 1), (Int.negSucc 1), (Int.negSucc 1))),
  (((Int.ofNat 0), (Int.ofNat 4)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 0)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 3), (Int.ofNat 2))),
  (((Int.ofNat 1), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.ofNat 2)), ((Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 1)))
]
theorem a4_be_certificate : fastMul a2_1 a2_1 = a4_be := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_a4_be : evalLaurent q U V a4_be = evalLaurent q U V a2_1 * evalLaurent q U V a2_1 := by
  rw [← a4_be_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def a4_ae : List Term := [
  (((Int.negSucc 2), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.negSucc 1), (Int.negSucc 2)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.negSucc 1), (Int.ofNat 0)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.negSucc 0)), ((Int.ofNat 1), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 1))),
  (((Int.negSucc 0), (Int.ofNat 2)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.negSucc 1)), ((Int.negSucc 0), (Int.negSucc 1), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 0), (Int.ofNat 1)), ((Int.negSucc 0), (Int.negSucc 3), (Int.negSucc 3), (Int.negSucc 2))),
  (((Int.ofNat 0), (Int.ofNat 4)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 0)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 1), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 2), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 2), (Int.ofNat 2)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 3), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0)))
]
theorem a4_ae_certificate : fastMul a2_0 a2_1 = a4_ae := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_a4_ae : evalLaurent q U V a4_ae = evalLaurent q U V a2_0 * evalLaurent q U V a2_1 := by
  rw [← a4_ae_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def a4_bd : List Term := [
  (((Int.negSucc 2), (Int.negSucc 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 1), (Int.negSucc 2)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 1), (Int.ofNat 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.negSucc 0)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.negSucc 0), (Int.ofNat 2)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.negSucc 1)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 1), (Int.negSucc 0))),
  (((Int.ofNat 0), (Int.ofNat 1)), ((Int.ofNat 1), (Int.negSucc 1), (Int.negSucc 2), (Int.negSucc 2))),
  (((Int.ofNat 0), (Int.ofNat 4)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 2), (Int.ofNat 2), (Int.ofNat 1))),
  (((Int.ofNat 1), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 2), (Int.negSucc 0)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.ofNat 2)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 3), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1)))
]
theorem a4_bd_certificate : fastMul a2_1 a2_0 = a4_bd := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_a4_bd : evalLaurent q U V a4_bd = evalLaurent q U V a2_1 * evalLaurent q U V a2_0 := by
  rw [← a4_bd_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def a4_0 : List Term := [
  (((Int.negSucc 3), (Int.negSucc 3)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 1), (Int.negSucc 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.negSucc 1), (Int.ofNat 0)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 0), (Int.negSucc 0)), ((Int.ofNat 4), (Int.ofNat 5), (Int.ofNat 4), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 1), (Int.ofNat 0)), ((Int.ofNat 0), (Int.negSucc 3), (Int.negSucc 4), (Int.negSucc 3))),
  (((Int.ofNat 1), (Int.ofNat 3)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 2), (Int.ofNat 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.ofNat 4), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem a4_0_certificate : subL a4_ad a4_be = a4_0 := by decide +kernel
theorem eval_a4_0 : evalLaurent q U V a4_0 = evalLaurent q U V a4_ad - evalLaurent q U V a4_be := by
  rw [← a4_0_certificate, eval_sub q U V]
def a4_sum : List Term := [
  (((Int.negSucc 2), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.negSucc 1), (Int.negSucc 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.negSucc 1), (Int.ofNat 0)), ((Int.ofNat 0), (Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.negSucc 0)), ((Int.ofNat 2), (Int.ofNat 3), (Int.ofNat 2), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.negSucc 1)), ((Int.negSucc 1), (Int.negSucc 2), (Int.negSucc 2), (Int.negSucc 1))),
  (((Int.ofNat 0), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 5), (Int.negSucc 6), (Int.negSucc 5))),
  (((Int.ofNat 0), (Int.ofNat 4)), ((Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 0)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 3), (Int.ofNat 2))),
  (((Int.ofNat 1), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 2), (Int.ofNat 2)), ((Int.negSucc 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 3), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem a4_sum_certificate : addL a4_ae a4_bd = a4_sum := by decide +kernel
theorem eval_a4_sum : evalLaurent q U V a4_sum = evalLaurent q U V a4_ae + evalLaurent q U V a4_bd := by
  rw [← a4_sum_certificate, eval_add q U V]
def a4_1 : List Term := [
  (((Int.negSucc 3), (Int.negSucc 3)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 2), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.negSucc 0), (Int.negSucc 0)), ((Int.ofNat 4), (Int.ofNat 5), (Int.ofNat 4), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.negSucc 1)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 0), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 3), (Int.negSucc 4), (Int.negSucc 3))),
  (((Int.ofNat 0), (Int.ofNat 4)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 2), (Int.ofNat 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.ofNat 3), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem a4_1_certificate : subL a4_sum a4_be = a4_1 := by decide +kernel
theorem eval_a4_1 : evalLaurent q U V a4_1 = evalLaurent q U V a4_sum - evalLaurent q U V a4_be := by
  rw [← a4_1_certificate, eval_sub q U V]
def ca0 : List Term := [
  (((Int.negSucc 0), (Int.negSucc 0)), ((Int.ofNat 5), (Int.ofNat 5), (Int.ofNat 5), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 0)), ((Int.ofNat 0), (Int.negSucc 4), (Int.negSucc 4), (Int.negSucc 4)))
]
theorem ca0_certificate : fastMul c a0 = ca0 := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_ca0 : evalLaurent q U V ca0 = evalLaurent q U V c * evalLaurent q U V a0 := by
  rw [← ca0_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def ca1 : List Term := [
  (((Int.negSucc 0), (Int.negSucc 0)), ((Int.ofNat 5), (Int.ofNat 5), (Int.ofNat 5), (Int.ofNat 0))),
  (((Int.ofNat 0), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 4), (Int.negSucc 4), (Int.negSucc 4)))
]
theorem ca1_certificate : fastMul c a1 = ca1 := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_ca1 : evalLaurent q U V ca1 = evalLaurent q U V c * evalLaurent q U V a1 := by
  rw [← ca1_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def ac0 : List Term := [
  (((Int.negSucc 3), (Int.negSucc 3)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 1), (Int.negSucc 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.negSucc 1), (Int.ofNat 0)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 0), (Int.negSucc 0)), ((Int.negSucc 0), (Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 1), (Int.ofNat 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 1), (Int.ofNat 3)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 2), (Int.ofNat 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.ofNat 4), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem ac0_certificate : subL a4_0 ca0 = ac0 := by decide +kernel
theorem eval_ac0 : evalLaurent q U V ac0 = evalLaurent q U V a4_0 - evalLaurent q U V ca0 := by
  rw [← ac0_certificate, eval_sub q U V]
def ac1 : List Term := [
  (((Int.negSucc 3), (Int.negSucc 3)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 2), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.negSucc 0), (Int.negSucc 0)), ((Int.negSucc 0), (Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.negSucc 1)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 0), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.ofNat 4)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 2), (Int.ofNat 2)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.ofNat 3), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem ac1_certificate : subL a4_1 ca1 = ac1 := by decide +kernel
theorem eval_ac1 : evalLaurent q U V ac1 = evalLaurent q U V a4_1 - evalLaurent q U V ca1 := by
  rw [← ac1_certificate, eval_sub q U V]
def p_ad : List Term := [
  (((Int.negSucc 4), (Int.negSucc 3)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 2), (Int.negSucc 2)), ((Int.negSucc 1), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 2), (Int.ofNat 0)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 1), (Int.negSucc 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.negSucc 1), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 1)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.ofNat 0)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 2))),
  (((Int.ofNat 0), (Int.ofNat 3)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 1), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 2)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.ofNat 2), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 3), (Int.ofNat 0)), ((Int.ofNat 2), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 3), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.ofNat 1)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem p_ad_certificate : fastMul ac0 b0 = p_ad := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_p_ad : evalLaurent q U V p_ad = evalLaurent q U V ac0 * evalLaurent q U V b0 := by
  rw [← p_ad_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def p_be : List Term := [
  (((Int.negSucc 3), (Int.negSucc 4)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 2), (Int.negSucc 2)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 1))),
  (((Int.negSucc 1), (Int.negSucc 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.negSucc 1)), ((Int.negSucc 0), (Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.negSucc 2)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.ofNat 0), (Int.ofNat 0)), ((Int.ofNat 0), (Int.ofNat 2), (Int.ofNat 0), (Int.ofNat 2))),
  (((Int.ofNat 0), (Int.ofNat 3)), ((Int.ofNat 1), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.negSucc 0)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 2)), ((Int.negSucc 0), (Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.ofNat 5)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 2), (Int.ofNat 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.ofNat 3), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 3), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.ofNat 2)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem p_be_certificate : fastMul ac1 b1 = p_be := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_p_be : evalLaurent q U V p_be = evalLaurent q U V ac1 * evalLaurent q U V b1 := by
  rw [← p_be_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
def p_ae : List Term := [
  (((Int.negSucc 3), (Int.negSucc 4)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.negSucc 2), (Int.negSucc 2)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 1), (Int.negSucc 3)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 0))),
  (((Int.negSucc 1), (Int.negSucc 0)), ((Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0), (Int.negSucc 0))),
  (((Int.negSucc 0), (Int.negSucc 1)), ((Int.negSucc 0), (Int.ofNat 1), (Int.negSucc 0), (Int.ofNat 0))),
  (((Int.negSucc 0), (Int.ofNat 1)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 2))),
  (((Int.ofNat 0), (Int.ofNat 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 0), (Int.ofNat 3)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 1), (Int.negSucc 0)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 1), (Int.ofNat 2)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 2), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 2), (Int.ofNat 1)), ((Int.ofNat 0), (Int.negSucc 0), (Int.ofNat 0), (Int.negSucc 1))),
  (((Int.ofNat 2), (Int.ofNat 4)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))),
  (((Int.ofNat 3), (Int.ofNat 0)), ((Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1), (Int.ofNat 1))),
  (((Int.ofNat 3), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 4), (Int.negSucc 0)), ((Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0))),
  (((Int.ofNat 5), (Int.ofNat 1)), ((Int.negSucc 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0)))
]
theorem p_ae_certificate : fastMul ac0 b1 = p_ae := by decide +kernel
include hQ hQ₅ h₄ h₅ hUV hQU hQV in
theorem eval_p_ae : evalLaurent q U V p_ae = evalLaurent q U V ac0 * evalLaurent q U V b1 := by
  rw [← p_ae_certificate, evalLaurent_fastMul q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV]
end CompactLaurentBridge
