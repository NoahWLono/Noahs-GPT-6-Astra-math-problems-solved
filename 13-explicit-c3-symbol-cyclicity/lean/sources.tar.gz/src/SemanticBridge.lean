module
public import LeafSemantics

@[expose] public section
namespace CompactLaurentBridge
open PrimeCyclicity CompactC3Invariance
variable {K D : Type*} [Field K] [DivisionRing D] [Algebra K D]

theorem numerator_eq_compact_explicit
    (q : K) (Q U V : Dˣ) (hQ : (Q:D)=algebraMap K D q)
    (hQ₅ : Q^5=1) (h₄ : q^4 = -(1+q+q^2+q^3)) (h₅ : q^5=1)
    (hUV : U*V=Q*V*U) (hQU : Commute Q U) (hQV : Commute Q V) :
    evalLaurent q U V numerator =
      compactNumerator (algebraMap K D q) (U : D) (V : D) ((U : D) * (V : D))⁻¹ := by
  have hW : evalLaurent q U V w = ((U : D) * (V : D))⁻¹ := by
    rw [eval_w q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV, leaf_vi, leaf_ui, mul_inv_rev]
  have hWI : evalLaurent q U V wi = (U : D) * (V : D) := by
    rw [eval_wi q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV, leaf_u, leaf_v]
  have hZ : evalLaurent q U V z = (((U : D) * (V : D))⁻¹) ^ 5 := by
    rw [eval_z q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
      eval_w4 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
      eval_w2 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV, hW]
    noncomm_ring
  rw [← result_eq_numerator]
  simp only [
eval_a0 q U V,
    eval_a1 q U V,
    eval_b0 q U V,
    eval_b1 q U V,
    eval_a2_ad q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
    eval_a2_be q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
    eval_a2_ae q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
    eval_a2_bd q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
    eval_a2_0 q U V,
    eval_a2_sum q U V,
    eval_a2_1 q U V,
    eval_a4_ad q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
    eval_a4_be q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
    eval_a4_ae q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
    eval_a4_bd q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
    eval_a4_0 q U V,
    eval_a4_sum q U V,
    eval_a4_1 q U V,
    eval_ca0 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
    eval_ca1 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
    eval_ac0 q U V,
    eval_ac1 q U V,
    eval_p_ad q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
    eval_p_be q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
    eval_p_ae q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
    eval_p_bd q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
    eval_p_0 q U V,
    eval_p_sum q U V,
    eval_p_1 q U V,
    eval_d0 q U V,
    eval_d1 q U V,
    eval_d0twice q U V,
    eval_e0 q U V,
    eval_d1twice q U V,
    eval_e1 q U V,
    eval_n0 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
    eval_n1 q Q U V hQ hQ₅ h₄ h₅ hUV hQU hQV,
    eval_result q U V,
    hW,
    hWI,
    hZ,
    leaf_u q U V,
    leaf_v q U V,
    leaf_ui q U V,
    leaf_vi q U V,
    leaf_x q U V,
    leaf_y q U V,
    leaf_c q U V h₄ h₅]
  dsimp [compactNumerator, pairing, covariant, quartic, pairMul, pairSub, leftScale,
    differencePair, inversePair, scalarPair]
  simp only [two_mul, inv_inv]

#print axioms numerator_eq_compact_explicit
end CompactLaurentBridge
