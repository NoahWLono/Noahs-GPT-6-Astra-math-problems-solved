module
public import GeneratedField

@[expose] public section
namespace PrimeCyclicityEndpoint
variable (F D : Type*) [Field F] [DivisionRing D] [Algebra F D]
  [FiniteDimensional F D]

/-- Explicit center-equals-scalars hypothesis, in a noncommutative ambient ring. -/
def CenterIsScalars : Prop :=
  ∀ z : D, (∀ d : D, z * d = d * z) → z ∈ Set.range (algebraMap F D)

/-- Maximality among all commutative F-subalgebras, hence among commutative subfields. -/
theorem generated_maximal_commutative (hd : Module.finrank F D = 25)
    (hc : CenterIsScalars F D) (r : D)
    (hn : r ∉ Set.range (algebraMap F D)) (a : F)
    (hp : r ^ 5 = algebraMap F D a)
    (M : Subalgebra F D) (hLM : Generated F D r ≤ M)
    (hcomm : ∀ x ∈ M, ∀ y ∈ M, x * y = y * x) :
    M = Generated F D r := by
  letI : CommRing M := { (inferInstance : Ring M) with
    mul_comm := fun x y => Subtype.ext (hcomm x x.property y y.property) }
  letI : Field M := fieldOfFiniteDimensional F M
  have hdiv : Module.finrank F M ∣ 25 := by
    rw [← hd]
    exact ⟨Module.finrank M D, (Module.finrank_mul_finrank F M D).symm⟩
  have hle : 5 ≤ Module.finrank F M := by
    rw [← generated_finrank_eq_five F D hd r hn a hp]
    exact Submodule.finrank_mono (show (Generated F D r).toSubmodule ≤ M.toSubmodule from hLM)
  have hne : Module.finrank F M ≠ 25 := by
    intro hdim
    have htop : M.toSubmodule = ⊤ := Submodule.eq_top_of_finrank_eq (hdim.trans hd.symm)
    have hall : ∀ d : D, d ∈ M := by
      intro d
      change d ∈ M.toSubmodule
      rw [htop]
      trivial
    exact hn (hc r (fun d => hcomm r (hall r) d (hall d)))
  have hdim : Module.finrank F M = 5 := by
    rcases divisor_twentyfive hdiv with h | h | h
    · omega
    · exact h
    · exact (hne h).elim
  exact (Subalgebra.eq_of_le_of_finrank_eq hLM
    ((generated_finrank_eq_five F D hd r hn a hp).trans hdim.symm)).symm

#print axioms generated_maximal_commutative
end PrimeCyclicityEndpoint
