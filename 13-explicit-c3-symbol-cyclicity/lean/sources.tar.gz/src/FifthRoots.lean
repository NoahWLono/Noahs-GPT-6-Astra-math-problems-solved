module
public import GeneratedField
public import Mathlib.RingTheory.RootsOfUnity.PrimitiveRoots

@[expose] public section
namespace PrimeCyclicityEndpoint
variable (F D : Type*) [Field F] [DivisionRing D] [Algebra F D]

/-- Every fifth root of unity in D is a scalar power of a primitive fifth root in F.
No finite-dimensionality or center-equality hypothesis is needed. -/
theorem fifth_root_is_scalar_power (ζ : F) (hζ : IsPrimitiveRoot ζ 5)
    (w : D) (hw : w ^ 5 = 1) :
    ∃ i : ℕ, i < 5 ∧ w = algebraMap F D (ζ ^ i) := by
  let L := Generated F D w
  have hz : IsPrimitiveRoot (algebraMap F L ζ) 5 :=
    hζ.map_of_injective (algebraMap F L).injective
  have hw' : (generator F D w) ^ 5 = 1 := by
    apply Subtype.val_injective
    simpa [generator] using hw
  obtain ⟨i, hi, heq⟩ := hz.eq_pow_of_pow_eq_one hw'
  refine ⟨i, hi, ?_⟩
  simpa [L, generator] using congrArg Subtype.val heq.symm

#print axioms fifth_root_is_scalar_power
end PrimeCyclicityEndpoint
