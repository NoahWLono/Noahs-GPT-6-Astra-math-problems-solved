module
public import BridgeBase

/- This assumes only support divisibility, never an N^5 identity. -/
@[expose] public section
namespace ConcreteCoordinateBridge
open PrimeCyclicity
variable {K A : Type*} [Field K] [DivisionRing A] [Algebra K A]

/-- Explicit scalar coefficient sum for a central-support Laurent expression. -/
def centralCoefficient (q x y : K) (p : List Term) : K :=
  (p.map fun t => evalCoeff q t.2 * (x ^ (t.1.1 / 5) * y ^ (t.1.2 / 5))).sum

theorem residue5_eq_zero_of_dvd (n : ℤ) (hn : 5 ∣ n) : residue5 n = 0 := by
  apply Fin.ext
  simp [residue5, Int.emod_eq_zero_of_dvd hn]

theorem evalTerm_scalar_of_support (q x y : K) (U V : Aˣ)
    (hU : (U : A) ^ 5 = algebraMap K A x)
    (hV : (V : A) ^ 5 = algebraMap K A y)
    (t : Term) (hi : 5 ∣ t.1.1) (hj : 5 ∣ t.1.2) :
    evalTerm q U V t = algebraMap K A
      (evalCoeff q t.2 * (x ^ (t.1.1 / 5) * y ^ (t.1.2 / 5))) := by
  rw [evalTerm_eq, Units.val_mul, normalize_zpow U x hU, normalize_zpow V y hV,
    residue5_eq_zero_of_dvd t.1.1 hi, residue5_eq_zero_of_dvd t.1.2 hj]
  simp [map_mul, mul_assoc]

/-- A finite central-support expression evaluates to the stated scalar, with no basis needed. -/
theorem evalLaurent_scalar_of_support (q x y : K) (U V : Aˣ)
    (hU : (U : A) ^ 5 = algebraMap K A x)
    (hV : (V : A) ^ 5 = algebraMap K A y)
    (p : List Term) (hs : ∀ t ∈ p, 5 ∣ t.1.1 ∧ 5 ∣ t.1.2) :
    evalLaurent q U V p = algebraMap K A (centralCoefficient q x y p) := by
  revert hs
  induction p with
  | nil => intro hs; simp [evalLaurent, centralCoefficient]
  | cons t p ih =>
    intro hs
    have ht := hs t (by simp)
    have hp : ∀ s ∈ p, 5 ∣ s.1.1 ∧ 5 ∣ s.1.2 := by
      intro s hsp
      exact hs s (by simp [hsp])
    change evalTerm q U V t + evalLaurent q U V p =
      algebraMap K A
        (evalCoeff q t.2 * (x ^ (t.1.1 / 5) * y ^ (t.1.2 / 5)) +
          centralCoefficient q x y p)
    rw [map_add, evalTerm_scalar_of_support q x y U V hU hV t ht.1 ht.2, ih hp]

/-- The scalar-support result implies commuting with every algebra element. -/
theorem evalLaurent_commutes_of_support (q x y : K) (U V : Aˣ)
    (hU : (U : A) ^ 5 = algebraMap K A x)
    (hV : (V : A) ^ 5 = algebraMap K A y)
    (p : List Term) (hs : ∀ t ∈ p, 5 ∣ t.1.1 ∧ 5 ∣ t.1.2) (a : A) :
    evalLaurent q U V p * a = a * evalLaurent q U V p := by
  rw [evalLaurent_scalar_of_support q x y U V hU hV p hs]
  exact Algebra.commutes _ _

/- Future use requires BOTH independently checked inputs:
  1. a theorem identifying N^5 with evalLaurent q U V output75;
  2. a kernel certificate: ∀ t ∈ output75, 5 ∣ t.1.1 ∧ 5 ∣ t.1.2.
The certificate can be proved by `decide` over the explicit closed list. Neither
input is asserted, introduced as an axiom, or built into this draft.
-/
end ConcreteCoordinateBridge
