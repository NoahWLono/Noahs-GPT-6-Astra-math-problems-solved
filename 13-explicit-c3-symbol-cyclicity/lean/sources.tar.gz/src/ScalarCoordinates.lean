module
public import BridgeBase
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
@[expose] public section
namespace ConcreteCoordinateBridge
open PrimeCyclicity Module
variable {K A : Type*} [Field K] [DivisionRing A] [Algebra K A]
theorem sum_coordinate_filter (q x y : K) (ij : Fin 5 × Fin 5) (p : List Term) :
    (p.map (termCoordinate q x y ij)).sum =
      ((p.filter fun t => (residue5 t.1.1, residue5 t.1.2) = ij).map
        (termCoordinate q x y ij)).sum := by
  induction p with
  | nil => rfl
  | cons t p ih =>
    by_cases h : (residue5 t.1.1, residue5 t.1.2) = ij
    · simpa [List.filter_cons, h] using congrArg (termCoordinate q x y ij t + ·) ih
    · simpa [List.filter_cons, h, termCoordinate] using ih

theorem filter13 :
    numerator.filter (fun t => (residue5 t.1.1, residue5 t.1.2) = (1, 3)) =
      [(((Int.negSucc 8), (Int.negSucc 6)), ((Int.ofNat 0), (Int.negSucc 1), (Int.ofNat 0), (Int.ofNat 0))), (((Int.negSucc 3), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0))), (((Int.ofNat 1), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 1), (Int.ofNat 0), (Int.ofNat 0)))] := by decide

theorem filter23 :
    numerator.filter (fun t => (residue5 t.1.1, residue5 t.1.2) = (2, 3)) =
      [(((Int.negSucc 2), (Int.negSucc 6)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))), (((Int.ofNat 2), (Int.ofNat 3)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 1))), (((Int.ofNat 7), (Int.negSucc 1)), ((Int.ofNat 0), (Int.ofNat 0), (Int.ofNat 0), (Int.negSucc 1)))] := by decide

/-- Closed finite list calculation, directly over the imported frozen numerator. -/
theorem numerator_coordinate13_raw (q x y : K) :
    (numerator.map (termCoordinate q x y (1, 3))).sum =
      q * (x⁻¹ + y⁻¹ - 2 * (x ^ 2)⁻¹ * (y ^ 2)⁻¹) := by
  rw [sum_coordinate_filter, filter13]
  norm_num [Int.toNat, Int.negSucc_eq, Fin.ext_iff, termCoordinate, residue5, evalCoeff, zpow_neg, zpow_negSucc, zpow_ofNat]
  <;> ring

/-- Closed finite list calculation, directly over the imported frozen numerator. -/
theorem numerator_coordinate23_raw (q x y : K) :
    (numerator.map (termCoordinate q x y (2, 3))).sum =
      q ^ 3 * (x⁻¹ * (y ^ 2)⁻¹ + 1 - 2 * x * y⁻¹) := by
  rw [sum_coordinate_filter, filter23]
  norm_num [Int.toNat, Int.negSucc_eq, Fin.ext_iff, termCoordinate, residue5, evalCoeff, zpow_neg, zpow_negSucc, zpow_ofNat]
  <;> ring

end ConcreteCoordinateBridge
