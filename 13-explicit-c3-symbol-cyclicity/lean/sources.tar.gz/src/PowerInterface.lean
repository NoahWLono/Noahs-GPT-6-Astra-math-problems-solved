module
public import StructuralAdapter
public import CentralSupport

@[expose] public section
noncomputable section
namespace PrimeFiveFamily
variable {K A : Type*} [Field K] [CharZero K] [DivisionRing A] [Algebra K A]
variable (s : SymbolFamily K A)

/-- The central scalar unit needed by the finite quantum-Laurent certificates. -/
def scalarQ : Aˣ := Units.mk0 (algebraMap K A s.q) (by
  intro h
  apply s.q_primitive.ne_zero (by decide)
  exact (algebraMap K A).injective (by simpa using h))

theorem scalarQ_coe : (scalarQ s : A) = algebraMap K A s.q := rfl

theorem scalarQ_fifth : scalarQ s ^ 5 = 1 := by
  apply Units.ext
  simp only [Units.val_pow_eq_pow_val, Units.val_one, scalarQ_coe,
    ← map_pow, s.q_primitive.pow_eq_one, map_one]

theorem scalarQ_commutes_U : Commute (scalarQ s) s.U := by
  change scalarQ s * s.U = s.U * scalarQ s
  apply Units.ext
  simpa only [Units.val_mul, scalarQ_coe] using Algebra.commutes s.q (s.U : A)

theorem scalarQ_commutes_V : Commute (scalarQ s) s.V := by
  change scalarQ s * s.V = s.V * scalarQ s
  apply Units.ext
  simpa only [Units.val_mul, scalarQ_coe] using Algebra.commutes s.q (s.V : A)

theorem quantum_units : s.U * s.V = scalarQ s * s.V * s.U := by
  apply Units.ext
  change (s.U : A) * s.V = algebraMap K A s.q * (s.V : A) * s.U
  simpa only [Algebra.smul_def, mul_assoc] using s.quantum

theorem q_cyclotomic_fourth : s.q ^ 4 = -(1 + s.q + s.q ^ 2 + s.q ^ 3) := by
  have hp : (s.q - 1) * (s.q ^ 4 + (1 + s.q + s.q ^ 2 + s.q ^ 3)) = 0 := by
    calc
      _ = s.q ^ 5 - 1 := by ring
      _ = 0 := by rw [s.q_primitive.pow_eq_one, sub_self]
  have hs := (mul_eq_zero.mp hp).resolve_left
    (sub_ne_zero.mpr (s.q_primitive.ne_one (by decide)))
  exact (eq_neg_iff_add_eq_zero).mpr hs

/-- Supporting implication only: a scalar fifth-power identity, once proved,
forces its scalar to belong to the actual fixed field. -/
theorem fifthPower_scalar_fixed (a : K)
    (hpower : frozenNumerator s ^ 5 = algebraMap K A a) : s.tau a = a := by
  apply (algebraMap K A).injective
  calc
    algebraMap K A (s.tau a) = s.sigma (algebraMap K A a) := (sigma_scalar s a).symm
    _ = s.sigma (frozenNumerator s ^ 5) := congrArg s.sigma hpower.symm
    _ = frozenNumerator s ^ 5 := by rw [map_pow, frozenNumerator_fixed]
    _ = algebraMap K A a := hpower

/-- Supporting lifting implication, not an asserted N^5 identity. -/
theorem fixedNumerator_fifth_of_identity (a : K)
    (hpower : frozenNumerator s ^ 5 = algebraMap K A a) :
    fixedNumerator s ^ 5 = algebraMap (FixedScalars s) (FixedAlgebra s)
      ⟨a, fifthPower_scalar_fixed s a hpower⟩ := by
  apply Subtype.ext
  exact hpower

/- Pending full certificate integration (not assumed):

A checked numerator_fifth theorem must first establish
  frozenNumerator s ^ 5 = PrimeCyclicity.evalLaurent s.q s.U s.V output75
using scalarQ_coe, scalarQ_fifth, q_cyclotomic_fourth, q_primitive.pow_eq_one,
quantum_units, scalarQ_commutes_U, and scalarQ_commutes_V.

A separate closed support certificate must establish
  ∀ t ∈ output75, 5 ∣ t.1.1 ∧ 5 ∣ t.1.2.

Then ConcreteCoordinateBridge.evalLaurent_scalar_of_support gives hpower with
  a := ConcreteCoordinateBridge.centralCoefficient s.q s.x s.y output75.
Only then apply the two supporting implications above and the cyclicity endpoint.
No theorem here concludes cyclicity from the SymbolFamily inputs alone.
-/
end PrimeFiveFamily
